
'use client';

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Filter, Download, Search, Calendar, X } from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";
import toast from "react-hot-toast";

interface LogFiltersProps {
  totalLogs: number;
}

export function LogFilters({ totalLogs }: LogFiltersProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  
  const [filterOpen, setFilterOpen] = useState(false);
  const [searchPhone, setSearchPhone] = useState(searchParams?.get('phone') || '');
  const [statusFilter, setStatusFilter] = useState(searchParams?.get('status') || 'all');
  const [dateFrom, setDateFrom] = useState(searchParams?.get('from') || '');
  const [dateTo, setDateTo] = useState(searchParams?.get('to') || '');

  const handleSearch = (phone: string) => {
    const params = new URLSearchParams(searchParams?.toString());
    if (phone) {
      params.set('phone', phone);
    } else {
      params.delete('phone');
    }
    router.push(`/logs?${params.toString()}`);
  };

  const handleFilterApply = () => {
    const params = new URLSearchParams();
    
    if (searchPhone) params.set('phone', searchPhone);
    if (statusFilter !== 'all') params.set('status', statusFilter);
    if (dateFrom) params.set('from', dateFrom);
    if (dateTo) params.set('to', dateTo);
    
    router.push(`/logs?${params.toString()}`);
    setFilterOpen(false);
    toast.success('Filtros aplicados com sucesso!');
  };

  const clearFilters = () => {
    setSearchPhone('');
    setStatusFilter('all');
    setDateFrom('');
    setDateTo('');
    router.push('/logs');
    toast.success('Filtros limpos!');
  };

  const handleExport = async () => {
    try {
      const params = new URLSearchParams(searchParams?.toString());
      params.set('export', 'csv');
      
      const response = await fetch(`/api/logs?${params.toString()}`);
      if (!response.ok) throw new Error('Erro ao exportar logs');
      
      const data = await response.json();
      
      // Simular download de CSV
      const csvContent = [
        'Data,Telefone,Status,Configuração,Duração,Erro',
        ...data.logs.map((log: any) => 
          `${new Date(log.createdAt).toLocaleString('pt-BR')},${log.phoneNumber},${log.status},${log.configuration?.name || 'N/A'},${log.duration || 'N/A'},${log.errorMessage || ''}`
        )
      ].join('\n');
      
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      
      link.setAttribute('href', url);
      link.setAttribute('download', `logs-${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast.success('Logs exportados com sucesso!');
      
    } catch (error) {
      toast.error('Erro ao exportar logs');
      console.error('Export error:', error);
    }
  };

  return (
    <div className="flex items-center space-x-2">
      {/* Search */}
      <div className="relative flex-1 max-w-md">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        <Input
          placeholder="Buscar por número de telefone..."
          value={searchPhone}
          onChange={(e) => setSearchPhone(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSearch(searchPhone)}
          className="pl-10"
        />
      </div>

      {/* Advanced Filters Dialog */}
      <Dialog open={filterOpen} onOpenChange={setFilterOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" className="gap-2">
            <Filter className="h-4 w-4" />
            Filtrar
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Filtros Avançados</DialogTitle>
            <DialogDescription>
              Configure filtros personalizados para os logs
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="phone">Número de Telefone</Label>
              <Input
                id="phone"
                value={searchPhone}
                onChange={(e) => setSearchPhone(e.target.value)}
                placeholder="Ex: 11999999999"
              />
            </div>
            
            <div>
              <Label htmlFor="status">Status</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  <SelectItem value="success">Sucesso</SelectItem>
                  <SelectItem value="error">Erro</SelectItem>
                  <SelectItem value="rate_limited">Rate Limited</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="dateFrom">Data inicial</Label>
                <Input
                  id="dateFrom"
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="dateTo">Data final</Label>
                <Input
                  id="dateTo"
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                />
              </div>
            </div>
            
            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={clearFilters} className="gap-2">
                <X className="h-4 w-4" />
                Limpar
              </Button>
              <Button onClick={handleFilterApply}>
                Aplicar Filtros
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Export Button */}
      <Button variant="outline" onClick={handleExport} className="gap-2">
        <Download className="h-4 w-4" />
        Exportar
      </Button>
    </div>
  );
}
