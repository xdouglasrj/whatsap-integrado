
"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { 
  Home,
  Webhook,
  BarChart3,
  Settings,
  MessageSquare,
  Zap,
  ChevronLeft,
  Activity,
  MessageCircle
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/dashboard", icon: Home },
  { name: "Webhook WhatsApp", href: "/dashboard/webhook", icon: Webhook },
  { name: "WhatsApp Setup", href: "/dashboard/whatsapp-setup", icon: MessageCircle },
  { name: "WhatsApp Config", href: "/dashboard/whatsapp", icon: MessageSquare },
  { name: "Logs & Analytics", href: "/dashboard/analytics", icon: BarChart3 },
  { name: "Sites IPTV", href: "/dashboard/sites", icon: Zap },
  { name: "Configurações", href: "/dashboard/settings", icon: Settings },
];

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const pathname = usePathname();

  return (
    <div className={cn(
      "flex flex-col bg-white border-r border-gray-200 transition-all duration-300",
      collapsed ? "w-16" : "w-64"
    )}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        {!collapsed && (
          <div className="flex items-center space-x-2">
            <Activity className="h-8 w-8 text-primary" />
            <span className="text-lg font-semibold">IPTV WhatsApp</span>
          </div>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setCollapsed(!collapsed)}
        >
          <ChevronLeft className={cn(
            "h-4 w-4 transition-transform",
            collapsed && "rotate-180"
          )} />
        </Button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-2 space-y-1">
        {navigation.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link key={item.name} href={item.href}>
              <div className={cn(
                "flex items-center px-3 py-2 text-sm rounded-md transition-colors",
                isActive 
                  ? "bg-primary/10 text-primary font-medium"
                  : "text-gray-700 hover:bg-gray-100",
                collapsed && "justify-center px-2"
              )}>
                <item.icon className={cn("h-5 w-5", !collapsed && "mr-3")} />
                {!collapsed && <span>{item.name}</span>}
              </div>
            </Link>
          );
        })}
      </nav>

      {/* Status Indicator */}
      <div className={cn(
        "p-4 border-t",
        collapsed && "px-2"
      )}>
        <div className={cn(
          "flex items-center space-x-2 text-sm",
          collapsed && "justify-center"
        )}>
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          {!collapsed && <span className="text-gray-600">Sistema Online</span>}
        </div>
      </div>
    </div>
  );
}
