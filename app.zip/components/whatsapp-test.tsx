
'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Send, CheckCircle2, AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function WhatsAppTest() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [formData, setFormData] = useState({
    provider: 'twilio',
    to: '',
    message: '🎉 Teste do sistema IPTV WhatsApp!\n\nSe você recebeu esta mensagem, a integração está funcionando perfeitamente! ✅'
  });

  const handleTest = async () => {
    if (!formData.to.trim()) {
      toast({
        title: "Erro",
        description: "Digite um número de WhatsApp",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    setResult(null);

    try {
      const response = await fetch('/api/whatsapp/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        setResult({ success: true, ...data });
        toast({
          title: "Sucesso!",
          description: "Mensagem enviada com sucesso",
        });
      } else {
        setResult({ success: false, error: data.error, details: data.details });
        toast({
          title: "Erro",
          description: data.error || "Erro ao enviar mensagem",
          variant: "destructive"
        });
      }
    } catch (error: any) {
      setResult({ success: false, error: "Erro de conexão", details: error.message });
      toast({
        title: "Erro",
        description: "Erro de conexão com o servidor",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Send className="h-5 w-5" />
          <span>Teste WhatsApp</span>
        </CardTitle>
        <CardDescription>
          Teste o envio direto de mensagens WhatsApp
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="provider">Provedor</Label>
            <Select value={formData.provider} onValueChange={(value) => setFormData(prev => ({ ...prev, provider: value }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="twilio">Twilio WhatsApp</SelectItem>
                <SelectItem value="meta">Meta Business</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="to">Número WhatsApp</Label>
            <Input
              id="to"
              placeholder="+5511999999999"
              value={formData.to}
              onChange={(e) => setFormData(prev => ({ ...prev, to: e.target.value }))}
            />
          </div>
        </div>

        <div>
          <Label htmlFor="message">Mensagem</Label>
          <Textarea
            id="message"
            placeholder="Digite sua mensagem..."
            value={formData.message}
            onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
            rows={4}
          />
        </div>

        <Button onClick={handleTest} disabled={loading} className="w-full">
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Enviando...
            </>
          ) : (
            <>
              <Send className="h-4 w-4 mr-2" />
              Enviar Teste
            </>
          )}
        </Button>

        {result && (
          <Alert className={result.success ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}>
            {result.success ? (
              <CheckCircle2 className="h-4 w-4 text-green-600" />
            ) : (
              <AlertTriangle className="h-4 w-4 text-red-600" />
            )}
            <AlertDescription>
              {result.success ? (
                <div className="space-y-2">
                  <p className="text-green-800 font-medium">✅ Mensagem enviada com sucesso!</p>
                  <div className="text-sm text-green-700">
                    <p><strong>Provedor:</strong> {result.provider}</p>
                    <p><strong>ID:</strong> {result.messageId}</p>
                    {result.status && <p><strong>Status:</strong> {result.status}</p>}
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-red-800 font-medium">❌ {result.error}</p>
                  {result.details && (
                    <p className="text-sm text-red-700">{result.details}</p>
                  )}
                  {result.missing && (
                    <div className="text-sm text-red-700">
                      <p><strong>Credenciais faltando:</strong></p>
                      <ul className="list-disc list-inside">
                        {result.missing.accountSid && <li>TWILIO_ACCOUNT_SID</li>}
                        {result.missing.authToken && <li>TWILIO_AUTH_TOKEN</li>}
                        {result.missing.whatsappNumber && <li>TWILIO_WHATSAPP_NUMBER</li>}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}
