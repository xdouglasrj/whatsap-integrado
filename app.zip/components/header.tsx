
'use client';

import { useSession, signOut } from "next-auth/react";
import { Button } from "@/components/ui/button";
import { 
  Settings, 
  LogOut, 
  Activity,
  Key,
  FileText,
  Smartphone
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

export function Header() {
  const { data: session } = useSession();
  const pathname = usePathname();

  const isActive = (path: string) => pathname === path;

  if (!session) return null;

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto max-w-7xl">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard" className="flex items-center space-x-2">
              <Smartphone className="h-6 w-6 text-primary" />
              <span className="font-bold text-lg">IPTV Integration</span>
            </Link>
            
            <nav className="hidden md:flex space-x-1">
              <Link href="/dashboard">
                <Button 
                  variant={isActive('/dashboard') ? 'default' : 'ghost'} 
                  size="sm"
                  className="gap-2"
                >
                  <Activity className="h-4 w-4" />
                  Dashboard
                </Button>
              </Link>
              
              <Link href="/configurations">
                <Button 
                  variant={isActive('/configurations') ? 'default' : 'ghost'} 
                  size="sm"
                  className="gap-2"
                >
                  <Settings className="h-4 w-4" />
                  Configurações
                </Button>
              </Link>

              <Link href="/api-keys">
                <Button 
                  variant={isActive('/api-keys') ? 'default' : 'ghost'} 
                  size="sm"
                  className="gap-2"
                >
                  <Key className="h-4 w-4" />
                  API Keys
                </Button>
              </Link>

              <Link href="/logs">
                <Button 
                  variant={isActive('/logs') ? 'default' : 'ghost'} 
                  size="sm"
                  className="gap-2"
                >
                  <FileText className="h-4 w-4" />
                  Logs
                </Button>
              </Link>
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            <span className="text-sm text-muted-foreground">
              {session?.user?.name || session?.user?.email}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => signOut()}
              className="gap-2"
            >
              <LogOut className="h-4 w-4" />
              Sair
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
