// Rate limiter functions moved to webhook handlers
// This file is kept for compatibility

export class RateLimiter {
  static async checkRateLimit(phoneNumber: string): Promise<boolean> {
    // Rate limiting is now handled directly in webhook handlers
    return true;
  }
  
  static async updateRateLimit(phoneNumber: string): Promise<void> {
    // Rate limiting is now handled directly in webhook handlers
    return;
  }
}