// IPTV service functions moved to webhook handlers
// This file is kept for compatibility

export class IPTVService {
  static async generateTest(configId: string): Promise<any> {
    // IPTV generation is now handled directly in webhook handlers
    return null;
  }
}