// Logger functions moved to webhook handlers
// This file is kept for compatibility

export class Logger {
  static async logRequest(data: any): Promise<void> {
    // Logging is now handled directly in webhook handlers
    console.log('Request logged:', data);
  }
  
  static async getRecentLogs(): Promise<any[]> {
    // Logs are now handled directly in webhook handlers
    return [];
  }
}