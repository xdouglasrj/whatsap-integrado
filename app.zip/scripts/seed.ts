import { db } from '../lib/db';

async function main() {
  try {
    // Criar usuário administrador padrão
    const admin = await db.user.upsert({
      where: { email: 'john@doe.com' },
      update: {},
      create: {
        email: 'john@doe.com',
        name: 'Administrador Sistema',
      }
    });

    console.log('✅ Usuário administrador criado:', admin.email);

    // Criar template de mensagem padrão
    const defaultTemplate = await db.messageTemplate.upsert({
      where: { name: 'default' },
      update: {},
      create: {
        name: 'default',
        template: `🎉 *Seja bem-vindo(a) à The Best!*

👤 *Usuário:* {{usuario}}
🔐 *Senha:* {{senha}}  
🌐 *URL DNS:* {{dns}}
⏰ *Validade:* {{validade}}

📺 *M3U8:* {{m3u8}}

💻 *Área do cliente:* {{area_cliente}}

⚠️ *Atenção: Você pode renovar sua assinatura através da área do cliente*`,
        isDefault: true,
        description: 'Template padrão para resposta de teste IPTV',
        variables: ['usuario', 'senha', 'dns', 'validade', 'm3u8', 'area_cliente']
      }
    });

    console.log('✅ Template padrão criado:', defaultTemplate.name);

    // Criar site IPTV padrão
    const defaultSite = await db.iPTVSite.upsert({
      where: { name: 'The Best IPTV' },
      update: {},
      create: {
        name: 'The Best IPTV',
        apiUrl: 'https://painel.best/sys/api.php',
        apiKey: 'rcQ5GD6SxV6e1JJbXB8JPWrNkkEEpaGt',
        isActive: true,
        rateLimit: 10,
        description: 'Site IPTV principal configurado'
      }
    });

    console.log('✅ Site IPTV configurado:', defaultSite.name);

    console.log('\n🎉 Seed executado com sucesso!');
    console.log('📋 Credenciais de acesso:');
    console.log('   Email: john@doe.com');
    console.log('   Senha: qualquer senha (autenticação simplificada)');
    console.log('🌐 Webhook URL: /api/webhook/whatsapp');

  } catch (error) {
    console.error('❌ Erro durante o seed:', error);
    throw error;
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });