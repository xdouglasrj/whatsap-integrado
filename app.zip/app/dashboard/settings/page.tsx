
"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Settings,
  Zap,
  MessageSquare,
  Shield,
  Save,
  RefreshCw
} from "lucide-react";
import { toast } from "sonner";

export default function SettingsPage() {
  const [loading, setLoading] = useState(false);
  const [config, setConfig] = useState({
    apiUrl: "https://painel.best/sys/api.php",
    apiKey: "rcQ5GD6SxV6e1JJbXB8JPWrNkkEEpaGt",
    rateLimitMinutes: 10,
    webhookEnabled: true,
    autoResponse: true,
    triggers: ["teste", "trial", "demo", "testar", "test", "quero teste"],
    messageTemplate: `🎉 *Seja bem-vindo(a) à The Best!*

👤 *Usuário:* {{usuario}}
🔐 *Senha:* {{senha}}
🌐 *URL DNS:* {{dns}}
⏰ *Validade:* {{validade}}

📺 *M3U8:* {{m3u8}}

💻 *Área do cliente:* {{area_cliente}}

⚠️ *Atenção: Você pode renovar sua assinatura através da área do cliente*`
  });

  const handleSave = async () => {
    setLoading(true);
    try {
      // Simular salvamento
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success("Configurações salvas com sucesso!");
    } catch (error) {
      toast.error("Erro ao salvar configurações");
    } finally {
      setLoading(false);
    }
  };

  const addTrigger = () => {
    const newTrigger = prompt("Digite uma nova palavra-chave:");
    if (newTrigger && !config.triggers.includes(newTrigger.toLowerCase())) {
      setConfig(prev => ({
        ...prev,
        triggers: [...prev.triggers, newTrigger.toLowerCase()]
      }));
    }
  };

  const removeTrigger = (trigger: string) => {
    setConfig(prev => ({
      ...prev,
      triggers: prev.triggers.filter(t => t !== trigger)
    }));
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Settings className="h-8 w-8 text-primary" />
            Configurações
          </h1>
          <p className="text-muted-foreground mt-2">
            Configure o sistema de integração IPTV-WhatsApp
          </p>
        </div>
        
        <Button onClick={handleSave} disabled={loading}>
          {loading ? (
            <>
              <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              Salvando...
            </>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              Salvar
            </>
          )}
        </Button>
      </div>

      <Tabs defaultValue="api" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="api">API IPTV</TabsTrigger>
          <TabsTrigger value="webhook">Webhook</TabsTrigger>
          <TabsTrigger value="messages">Mensagens</TabsTrigger>
          <TabsTrigger value="security">Segurança</TabsTrigger>
        </TabsList>

        <TabsContent value="api">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-blue-500" />
                Configuração da API IPTV
              </CardTitle>
              <CardDescription>
                Configure a conexão com o site de IPTV
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="api-url">URL da API</Label>
                <Input
                  id="api-url"
                  value={config.apiUrl}
                  onChange={(e) => setConfig(prev => ({ ...prev, apiUrl: e.target.value }))}
                  placeholder="https://painel.best/sys/api.php"
                />
              </div>

              <div>
                <Label htmlFor="api-key">API Key</Label>
                <Input
                  id="api-key"
                  type="password"
                  value={config.apiKey}
                  onChange={(e) => setConfig(prev => ({ ...prev, apiKey: e.target.value }))}
                  placeholder="Sua chave de API"
                />
                <p className="text-sm text-muted-foreground mt-1">
                  Chave fornecida pelo provedor IPTV
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="auto-response"
                  checked={config.autoResponse}
                  onCheckedChange={(checked) => setConfig(prev => ({ ...prev, autoResponse: checked }))}
                />
                <Label htmlFor="auto-response">Resposta automática ativada</Label>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="webhook">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-green-500" />
                Configuração do Webhook
              </CardTitle>
              <CardDescription>
                Configure rate limiting e segurança
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="rate-limit">Rate Limit (minutos)</Label>
                <Input
                  id="rate-limit"
                  type="number"
                  value={config.rateLimitMinutes}
                  onChange={(e) => setConfig(prev => ({ ...prev, rateLimitMinutes: parseInt(e.target.value) }))}
                  min="1"
                  max="60"
                />
                <p className="text-sm text-muted-foreground mt-1">
                  Tempo mínimo entre testes por usuário
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="webhook-enabled"
                  checked={config.webhookEnabled}
                  onCheckedChange={(checked) => setConfig(prev => ({ ...prev, webhookEnabled: checked }))}
                />
                <Label htmlFor="webhook-enabled">Webhook ativado</Label>
              </div>

              <div>
                <Label>Palavras-chave</Label>
                <div className="flex flex-wrap gap-2 mt-2 mb-2">
                  {config.triggers.map((trigger) => (
                    <Badge key={trigger} variant="secondary" className="cursor-pointer">
                      {trigger}
                      <button
                        onClick={() => removeTrigger(trigger)}
                        className="ml-2 text-red-500 hover:text-red-700"
                      >
                        ×
                      </button>
                    </Badge>
                  ))}
                </div>
                <Button variant="outline" onClick={addTrigger} size="sm">
                  Adicionar Palavra-chave
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="messages">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-purple-500" />
                Template de Mensagem
              </CardTitle>
              <CardDescription>
                Configure a mensagem de resposta automática
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="message-template">Template</Label>
                <Textarea
                  id="message-template"
                  value={config.messageTemplate}
                  onChange={(e) => setConfig(prev => ({ ...prev, messageTemplate: e.target.value }))}
                  rows={15}
                  className="font-mono text-sm"
                />
                <p className="text-sm text-muted-foreground mt-2">
                  Variáveis disponíveis: {"{"}{"{"} usuario {"}"}{"}"}, {"{"}{"{"} senha {"}"}{"}"}, {"{"}{"{"} dns {"}"}{"}"}, {"{"}{"{"} validade {"}"}{"}"}, {"{"}{"{"} m3u8 {"}"}{"}"}, {"{"}{"{"} area_cliente {"}"}{"}"}
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-red-500" />
                Segurança
              </CardTitle>
              <CardDescription>
                Configurações de segurança e monitoramento
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span>Log de atividades</span>
                  <Badge className="bg-green-100 text-green-800">Ativo</Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <span>Rate limiting</span>
                  <Badge className="bg-green-100 text-green-800">Ativo</Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <span>Validação de origem</span>
                  <Badge className="bg-yellow-100 text-yellow-800">Opcional</Badge>
                </div>
              </div>

              <div className="pt-4 border-t">
                <h4 className="font-medium mb-2">Limpeza automática</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Logs antigos são removidos automaticamente após 30 dias
                </p>
                <Button variant="outline" size="sm">
                  Limpar logs agora
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
