
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, XCircle, AlertCircle, ExternalLink, Copy } from 'lucide-react';
import { toast } from 'sonner';
import { WhatsAppTest } from '@/components/whatsapp-test';

interface WhatsAppConfig {
  enabled: boolean;
  access_token: string;
  phone_number_id: string;
  verify_token: string;
}

export default function WhatsAppConfigPage() {
  const [config, setConfig] = useState<WhatsAppConfig>({
    enabled: false,
    access_token: '',
    phone_number_id: '',
    verify_token: ''
  });
  
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  // Carregar configuração atual
  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = async () => {
    try {
      const response = await fetch('/api/dashboard/whatsapp-config');
      if (response.ok) {
        const data = await response.json();
        setConfig(data);
      }
    } catch (error) {
      console.error('Erro ao carregar configuração:', error);
    }
  };

  const saveConfig = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/dashboard/whatsapp-config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(config),
      });

      const result = await response.json();
      
      if (response.ok) {
        toast.success('Configuração salva com sucesso!');
      } else {
        toast.error(result.error || 'Erro ao salvar configuração');
      }
    } catch (error) {
      toast.error('Erro ao salvar configuração');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const testConnection = async () => {
    setTesting(true);
    setTestResult(null);
    
    try {
      const response = await fetch('/api/dashboard/whatsapp-test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(config),
      });

      const result = await response.json();
      setTestResult(result);
      
      if (result.success) {
        toast.success('Teste realizado com sucesso!');
      } else {
        toast.error('Teste falhou: ' + result.message);
      }
    } catch (error) {
      setTestResult({ success: false, message: 'Erro de conexão' });
      toast.error('Erro ao testar conexão');
      console.error(error);
    } finally {
      setTesting(false);
    }
  };

  const copyWebhookUrl = () => {
    if (webhookUrl) {
      navigator.clipboard.writeText(webhookUrl);
      toast.success('URL copiada para área de transferência!');
    }
  };

  const [webhookUrl, setWebhookUrl] = useState('');

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setWebhookUrl(`${window.location.origin}/api/webhook/whatsapp`);
    }
  }, []);

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Configuração WhatsApp Business</h1>
          <p className="text-gray-600 mt-2">Configure o envio direto de mensagens via WhatsApp Business API</p>
        </div>
      </div>

      {/* Status atual */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {config.enabled ? (
              <CheckCircle className="h-5 w-5 text-green-500" />
            ) : (
              <XCircle className="h-5 w-5 text-red-500" />
            )}
            Status do Sistema
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="font-medium">Envio Direto WhatsApp</span>
              <span className={`px-2 py-1 rounded text-sm ${
                config.enabled ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}>
                {config.enabled ? 'ATIVO' : 'INATIVO'}
              </span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="font-medium">URL do Webhook</span>
              <div className="flex items-center gap-2">
                <code className="text-sm bg-white px-2 py-1 rounded border">
                  {webhookUrl}
                </code>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={copyWebhookUrl}
                  className="p-2"
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Configuração */}
      <Card>
        <CardHeader>
          <CardTitle>Credenciais WhatsApp Business API</CardTitle>
          <CardDescription>
            Configure suas credenciais do Meta Business para envio automático de mensagens.
            <Button
              variant="link"
              className="p-0 h-auto font-normal text-blue-600 inline-flex items-center gap-1"
              onClick={() => window.open('https://developers.facebook.com/docs/whatsapp/business-management-api/get-started', '_blank')}
            >
              Ver documentação <ExternalLink className="h-3 w-3" />
            </Button>
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-2">
            <Switch
              id="enabled"
              checked={config.enabled}
              onCheckedChange={(checked) => setConfig({ ...config, enabled: checked })}
            />
            <Label htmlFor="enabled" className="font-medium">
              Habilitar envio direto via WhatsApp Business API
            </Label>
          </div>

          {config.enabled && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Quando habilitado, o sistema enviará mensagens diretamente ao WhatsApp sem depender do BotStar.
              </AlertDescription>
            </Alert>
          )}

          <div className="grid gap-4">
            <div>
              <Label htmlFor="access_token">Access Token do WhatsApp Business</Label>
              <Input
                id="access_token"
                type="password"
                placeholder="EAABcD123..."
                value={config.access_token}
                onChange={(e) => setConfig({ ...config, access_token: e.target.value })}
                className="font-mono"
              />
              <p className="text-sm text-gray-500 mt-1">
                Token de acesso permanente da sua aplicação Meta Business
              </p>
            </div>

            <div>
              <Label htmlFor="phone_number_id">Phone Number ID</Label>
              <Input
                id="phone_number_id"
                placeholder="123456789012345"
                value={config.phone_number_id}
                onChange={(e) => setConfig({ ...config, phone_number_id: e.target.value })}
                className="font-mono"
              />
              <p className="text-sm text-gray-500 mt-1">
                ID do número de telefone configurado no Meta Business
              </p>
            </div>

            <div>
              <Label htmlFor="verify_token">Verify Token</Label>
              <Input
                id="verify_token"
                placeholder="meu-token-secreto"
                value={config.verify_token}
                onChange={(e) => setConfig({ ...config, verify_token: e.target.value })}
                className="font-mono"
              />
              <p className="text-sm text-gray-500 mt-1">
                Token usado para verificar o webhook (configurado no Meta Business)
              </p>
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <Button onClick={saveConfig} disabled={loading}>
              {loading ? 'Salvando...' : 'Salvar Configuração'}
            </Button>
            
            {config.enabled && config.access_token && config.phone_number_id && (
              <Button variant="outline" onClick={testConnection} disabled={testing}>
                {testing ? 'Testando...' : 'Testar Conexão'}
              </Button>
            )}
          </div>

          {testResult && (
            <Alert className={testResult.success ? 'border-green-500' : 'border-red-500'}>
              {testResult.success ? (
                <CheckCircle className="h-4 w-4 text-green-500" />
              ) : (
                <XCircle className="h-4 w-4 text-red-500" />
              )}
              <AlertDescription>
                {testResult.message}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Teste WhatsApp */}
      <WhatsAppTest />

      {/* Como configurar */}
      <Card>
        <CardHeader>
          <CardTitle>Como configurar</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                1
              </div>
              <div>
                <h4 className="font-medium">Criar aplicação Meta Business</h4>
                <p className="text-sm text-gray-600">
                  Acesse o Meta for Developers e crie uma nova aplicação Business
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                2
              </div>
              <div>
                <h4 className="font-medium">Configurar WhatsApp Business API</h4>
                <p className="text-sm text-gray-600">
                  Adicione o produto WhatsApp e configure um número de telefone
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                3
              </div>
              <div>
                <h4 className="font-medium">Obter credenciais</h4>
                <p className="text-sm text-gray-600">
                  Copie o Access Token e Phone Number ID da sua aplicação
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                4
              </div>
              <div>
                <h4 className="font-medium">Configurar webhook</h4>
                <p className="text-sm text-gray-600">
                  Configure a URL do webhook no Meta Business apontando para: <br />
                  <code className="text-xs bg-gray-100 px-1 py-0.5 rounded">{webhookUrl || '/api/webhook/whatsapp'}</code>
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
