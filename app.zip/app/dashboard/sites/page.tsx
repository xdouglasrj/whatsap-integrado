
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { 
  Zap,
  Plus,
  Edit3,
  Trash2,
  Save,
  RefreshCw,
  Globe,
  Key,
  Activity
} from "lucide-react";
import { toast } from "sonner";

interface IPTVSite {
  id: string;
  name: string;
  apiUrl: string;
  apiKey: string;
  isActive: boolean;
  rateLimit: number;
  description?: string;
  createdAt: string;
  lastTest?: string;
  testsCount: number;
}

export default function SitesPage() {
  const [sites, setSites] = useState<IPTVSite[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newSite, setNewSite] = useState({
    name: "",
    apiUrl: "",
    apiKey: "",
    description: "",
    rateLimit: 10
  });

  const fetchSites = async () => {
    try {
      setLoading(true);
      
      // Simular dados para demonstração
      const mockSites: IPTVSite[] = [
        {
          id: "1",
          name: "The Best IPTV",
          apiUrl: "https://painel.best/sys/api.php",
          apiKey: "rcQ5GD6SxV6e1JJbXB8JPWrNkkEEpaGt",
          isActive: true,
          rateLimit: 10,
          description: "Site principal de IPTV",
          createdAt: new Date().toISOString(),
          lastTest: new Date().toISOString(),
          testsCount: 247
        },
        {
          id: "2",
          name: "IPTV Premium",
          apiUrl: "https://premium.iptv.com/api/test",
          apiKey: "premium_api_key_123",
          isActive: false,
          rateLimit: 5,
          description: "Site premium - teste",
          createdAt: new Date().toISOString(),
          testsCount: 0
        }
      ];

      await new Promise(resolve => setTimeout(resolve, 500)); // Simular delay
      setSites(mockSites);
    } catch (error) {
      console.error('Erro ao buscar sites:', error);
      toast.error('Erro ao carregar sites IPTV');
    } finally {
      setLoading(false);
    }
  };

  const saveSite = async () => {
    if (!newSite.name.trim() || !newSite.apiUrl.trim() || !newSite.apiKey.trim()) {
      toast.error('Nome, URL da API e chave são obrigatórios');
      return;
    }

    try {
      const site: IPTVSite = {
        id: Date.now().toString(),
        name: newSite.name,
        apiUrl: newSite.apiUrl,
        apiKey: newSite.apiKey,
        description: newSite.description,
        rateLimit: newSite.rateLimit,
        isActive: true,
        createdAt: new Date().toISOString(),
        testsCount: 0
      };
      
      setSites(prev => [...prev, site]);
      setNewSite({ name: "", apiUrl: "", apiKey: "", description: "", rateLimit: 10 });
      toast.success('Site IPTV salvo com sucesso!');
    } catch (error) {
      toast.error('Erro ao salvar site IPTV');
    }
  };

  const deleteSite = async (id: string) => {
    if (confirm('Tem certeza que deseja excluir este site IPTV?')) {
      setSites(prev => prev.filter(s => s.id !== id));
      toast.success('Site IPTV excluído com sucesso!');
    }
  };

  const toggleActive = async (id: string) => {
    setSites(prev => prev.map(s => 
      s.id === id ? { ...s, isActive: !s.isActive } : s
    ));
    const site = sites.find(s => s.id === id);
    toast.success(`Site ${site?.isActive ? 'desativado' : 'ativado'} com sucesso!`);
  };

  const testConnection = async (site: IPTVSite) => {
    toast.info(`Testando conexão com ${site.name}...`);
    
    try {
      // Simular teste de conexão
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Simular resultado aleatório
      const success = Math.random() > 0.3;
      
      if (success) {
        toast.success(`Conexão com ${site.name} está funcionando!`);
        setSites(prev => prev.map(s => 
          s.id === site.id ? { ...s, lastTest: new Date().toISOString() } : s
        ));
      } else {
        toast.error(`Falha na conexão com ${site.name}`);
      }
    } catch (error) {
      toast.error(`Erro ao testar ${site.name}`);
    }
  };

  useEffect(() => {
    fetchSites();
  }, []);

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Zap className="h-8 w-8 text-primary" />
            Sites IPTV
          </h1>
          <p className="text-muted-foreground mt-2">
            Gerencie os sites de IPTV configurados
          </p>
        </div>
        
        <Button onClick={fetchSites} disabled={loading}>
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Atualizar
        </Button>
      </div>

      {/* Novo Site */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5 text-green-500" />
            Novo Site IPTV
          </CardTitle>
          <CardDescription>
            Adicione um novo site de IPTV
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="site-name">Nome do Site</Label>
              <Input
                id="site-name"
                value={newSite.name}
                onChange={(e) => setNewSite(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Ex: IPTV Premium"
              />
            </div>
            <div>
              <Label htmlFor="rate-limit">Rate Limit (minutos)</Label>
              <Input
                id="rate-limit"
                type="number"
                value={newSite.rateLimit}
                onChange={(e) => setNewSite(prev => ({ ...prev, rateLimit: parseInt(e.target.value) }))}
                min="1"
                max="60"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="api-url">URL da API</Label>
            <Input
              id="api-url"
              value={newSite.apiUrl}
              onChange={(e) => setNewSite(prev => ({ ...prev, apiUrl: e.target.value }))}
              placeholder="https://exemplo.com/api/test"
            />
          </div>

          <div>
            <Label htmlFor="api-key">Chave da API</Label>
            <Input
              id="api-key"
              type="password"
              value={newSite.apiKey}
              onChange={(e) => setNewSite(prev => ({ ...prev, apiKey: e.target.value }))}
              placeholder="Sua chave de API"
            />
          </div>

          <div>
            <Label htmlFor="site-description">Descrição (opcional)</Label>
            <Textarea
              id="site-description"
              value={newSite.description}
              onChange={(e) => setNewSite(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Descrição do site IPTV"
              rows={3}
            />
          </div>

          <Button onClick={saveSite}>
            <Save className="w-4 h-4 mr-2" />
            Salvar Site
          </Button>
        </CardContent>
      </Card>

      {/* Lista de Sites */}
      <div className="grid gap-6">
        {loading ? (
          <Card>
            <CardContent className="text-center py-8">
              <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2" />
              <p>Carregando sites...</p>
            </CardContent>
          </Card>
        ) : sites.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8 text-muted-foreground">
              <Zap className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Nenhum site IPTV configurado</p>
            </CardContent>
          </Card>
        ) : (
          sites.map((site) => (
            <Card key={site.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <CardTitle className="flex items-center gap-2">
                      <Globe className="h-5 w-5 text-blue-500" />
                      {site.name}
                      {site.isActive ? (
                        <Badge className="bg-green-100 text-green-800">Ativo</Badge>
                      ) : (
                        <Badge variant="secondary">Inativo</Badge>
                      )}
                    </CardTitle>
                    {site.description && (
                      <CardDescription className="mt-1">{site.description}</CardDescription>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => testConnection(site)}
                      disabled={!site.isActive}
                    >
                      <Activity className="w-4 h-4 mr-1" />
                      Testar
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditingId(site.id)}
                    >
                      <Edit3 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => deleteSite(site.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Configurações */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium">URL da API</Label>
                      <div className="flex items-center gap-2 mt-1">
                        <Globe className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-mono bg-gray-100 px-2 py-1 rounded">
                          {site.apiUrl}
                        </span>
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium">Chave da API</Label>
                      <div className="flex items-center gap-2 mt-1">
                        <Key className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-mono bg-gray-100 px-2 py-1 rounded">
                          ••••••••{site.apiKey.slice(-4)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Estatísticas */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{site.testsCount}</div>
                      <div className="text-sm text-blue-800">Testes realizados</div>
                    </div>
                    
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{site.rateLimit}min</div>
                      <div className="text-sm text-green-800">Rate limit</div>
                    </div>
                    
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <div className="text-sm font-medium text-purple-600">
                        {site.lastTest ? 'Último teste' : 'Nunca testado'}
                      </div>
                      <div className="text-xs text-purple-800">
                        {site.lastTest 
                          ? new Date(site.lastTest).toLocaleString('pt-BR')
                          : '-'
                        }
                      </div>
                    </div>
                  </div>

                  {/* Controles */}
                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="flex items-center space-x-2">
                      <Switch
                        id={`active-${site.id}`}
                        checked={site.isActive}
                        onCheckedChange={() => toggleActive(site.id)}
                      />
                      <Label htmlFor={`active-${site.id}`} className="text-sm">
                        Site ativo
                      </Label>
                    </div>
                    
                    <div className="text-xs text-muted-foreground">
                      Criado em: {new Date(site.createdAt).toLocaleString('pt-BR')}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
