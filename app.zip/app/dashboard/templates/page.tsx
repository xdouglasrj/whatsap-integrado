
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  MessageSquare,
  Plus,
  Edit3,
  Trash2,
  Save,
  RefreshCw,
  Eye
} from "lucide-react";
import { toast } from "sonner";

interface Template {
  id: string;
  name: string;
  template: string;
  isDefault: boolean;
  description?: string;
  variables: string[];
  createdAt: string;
}

export default function TemplatesPage() {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState<string | null>(null);
  const [newTemplate, setNewTemplate] = useState({
    name: "",
    template: "",
    description: ""
  });

  const defaultTemplate = `🎉 *Seja bem-vindo(a) à The Best!*

👤 *Usuário:* {{usuario}}
🔐 *Senha:* {{senha}}
🌐 *URL DNS:* {{dns}}
⏰ *Validade:* {{validade}}

📺 *M3U8:* {{m3u8}}

💻 *Área do cliente:* {{area_cliente}}

⚠️ *Atenção: Você pode renovar sua assinatura através da área do cliente*`;

  const fetchTemplates = async () => {
    try {
      setLoading(true);
      
      // Simular dados para demonstração
      const mockTemplates: Template[] = [
        {
          id: "1",
          name: "Padrão",
          template: defaultTemplate,
          isDefault: true,
          description: "Template padrão para resposta de teste IPTV",
          variables: ["usuario", "senha", "dns", "validade", "m3u8", "area_cliente"],
          createdAt: new Date().toISOString()
        },
        {
          id: "2", 
          name: "Simples",
          template: `🔑 *Credenciais de Teste*

Usuário: {{usuario}}
Senha: {{senha}}
DNS: {{dns}}
Validade: {{validade}}`,
          isDefault: false,
          description: "Template simplificado sem formatação extra",
          variables: ["usuario", "senha", "dns", "validade"],
          createdAt: new Date().toISOString()
        }
      ];
      
      setTemplates(mockTemplates);
    } catch (error) {
      console.error('Erro ao buscar templates:', error);
      toast.error('Erro ao carregar templates');
    } finally {
      setLoading(false);
    }
  };

  const saveTemplate = async () => {
    if (!newTemplate.name.trim() || !newTemplate.template.trim()) {
      toast.error('Nome e template são obrigatórios');
      return;
    }

    try {
      // Simular salvamento
      const template: Template = {
        id: Date.now().toString(),
        name: newTemplate.name,
        template: newTemplate.template,
        description: newTemplate.description,
        isDefault: false,
        variables: extractVariables(newTemplate.template),
        createdAt: new Date().toISOString()
      };
      
      setTemplates(prev => [...prev, template]);
      setNewTemplate({ name: "", template: "", description: "" });
      toast.success('Template salvo com sucesso!');
    } catch (error) {
      toast.error('Erro ao salvar template');
    }
  };

  const extractVariables = (template: string): string[] => {
    const regex = /\{\{(\w+)\}\}/g;
    const variables: string[] = [];
    let match;
    
    while ((match = regex.exec(template)) !== null) {
      if (!variables.includes(match[1])) {
        variables.push(match[1]);
      }
    }
    
    return variables;
  };

  const deleteTemplate = async (id: string) => {
    const template = templates.find(t => t.id === id);
    if (template?.isDefault) {
      toast.error('Não é possível excluir o template padrão');
      return;
    }

    if (confirm('Tem certeza que deseja excluir este template?')) {
      setTemplates(prev => prev.filter(t => t.id !== id));
      toast.success('Template excluído com sucesso!');
    }
  };

  const setAsDefault = async (id: string) => {
    setTemplates(prev => prev.map(t => ({
      ...t,
      isDefault: t.id === id
    })));
    toast.success('Template definido como padrão!');
  };

  const previewTemplate = (template: string) => {
    return template
      .replace(/\{\{usuario\}\}/g, "teste123")
      .replace(/\{\{senha\}\}/g, "senha123")
      .replace(/\{\{dns\}\}/g, "http://exemplo.com")
      .replace(/\{\{validade\}\}/g, "24 horas")
      .replace(/\{\{m3u8\}\}/g, "http://exemplo.com/playlist.m3u8")
      .replace(/\{\{area_cliente\}\}/g, "http://cliente.exemplo.com");
  };

  useEffect(() => {
    fetchTemplates();
  }, []);

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <MessageSquare className="h-8 w-8 text-primary" />
            Templates de Mensagem
          </h1>
          <p className="text-muted-foreground mt-2">
            Gerencie os templates de resposta automática
          </p>
        </div>
        
        <Button onClick={fetchTemplates} disabled={loading}>
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Atualizar
        </Button>
      </div>

      {/* Novo Template */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5 text-green-500" />
            Novo Template
          </CardTitle>
          <CardDescription>
            Crie um novo template de mensagem
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="template-name">Nome do Template</Label>
              <Input
                id="template-name"
                value={newTemplate.name}
                onChange={(e) => setNewTemplate(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Ex: Template Premium"
              />
            </div>
            <div>
              <Label htmlFor="template-description">Descrição (opcional)</Label>
              <Input
                id="template-description"
                value={newTemplate.description}
                onChange={(e) => setNewTemplate(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Descrição do template"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="template-content">Conteúdo do Template</Label>
            <Textarea
              id="template-content"
              value={newTemplate.template}
              onChange={(e) => setNewTemplate(prev => ({ ...prev, template: e.target.value }))}
              rows={10}
              className="font-mono text-sm"
              placeholder="Digite seu template aqui usando {{variavel}} para campos dinâmicos"
            />
            <p className="text-sm text-muted-foreground mt-1">
              Variáveis disponíveis: {"{"}{"{"} usuario {"}"}{"}"}
              , {"{"}{"{"} senha {"}"}{"}"}
              , {"{"}{"{"} dns {"}"}{"}"}
              , {"{"}{"{"} validade {"}"}{"}"}
              , {"{"}{"{"} m3u8 {"}"}{"}"}
              , {"{"}{"{"} area_cliente {"}"}{"}"}
            </p>
          </div>

          <Button onClick={saveTemplate}>
            <Save className="w-4 h-4 mr-2" />
            Salvar Template
          </Button>
        </CardContent>
      </Card>

      {/* Lista de Templates */}
      <div className="grid gap-6">
        {loading ? (
          <Card>
            <CardContent className="text-center py-8">
              <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2" />
              <p>Carregando templates...</p>
            </CardContent>
          </Card>
        ) : templates.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8 text-muted-foreground">
              <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Nenhum template encontrado</p>
            </CardContent>
          </Card>
        ) : (
          templates.map((template) => (
            <Card key={template.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      {template.name}
                      {template.isDefault && (
                        <Badge className="bg-green-100 text-green-800">Padrão</Badge>
                      )}
                    </CardTitle>
                    {template.description && (
                      <CardDescription>{template.description}</CardDescription>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowPreview(showPreview === template.id ? null : template.id)}
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                    {!template.isDefault && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setAsDefault(template.id)}
                      >
                        Definir como Padrão
                      </Button>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditingId(template.id)}
                    >
                      <Edit3 className="w-4 h-4" />
                    </Button>
                    {!template.isDefault && (
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => deleteTemplate(template.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {/* Variáveis */}
                  <div>
                    <Label>Variáveis utilizadas:</Label>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {template.variables.map((variable) => (
                        <Badge key={variable} variant="secondary" className="text-xs">
                          {"{"}{"{"} {variable} {"}"}{"}"} 
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Preview */}
                  {showPreview === template.id && (
                    <div>
                      <Label>Preview:</Label>
                      <div className="bg-gray-50 p-3 rounded-md mt-1 border">
                        <pre className="text-sm whitespace-pre-wrap font-mono">
                          {previewTemplate(template.template)}
                        </pre>
                      </div>
                    </div>
                  )}

                  {/* Template original */}
                  <div>
                    <Label>Template:</Label>
                    <div className="bg-gray-50 p-3 rounded-md mt-1 border max-h-32 overflow-y-auto">
                      <pre className="text-sm whitespace-pre-wrap font-mono text-gray-700">
                        {template.template}
                      </pre>
                    </div>
                  </div>

                  <div className="text-xs text-muted-foreground">
                    Criado em: {new Date(template.createdAt).toLocaleString('pt-BR')}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
