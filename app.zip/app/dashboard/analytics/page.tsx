
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  BarChart3,
  TrendingUp,
  Users,
  Activity,
  RefreshCw,
  Calendar
} from "lucide-react";
import { toast } from "sonner";

interface AnalyticsData {
  totalTests: number;
  successfulTests: number;
  failedTests: number;
  rateLimited: number;
  uniqueUsers: number;
  dailyStats: Array<{
    date: string;
    tests: number;
    success: number;
    failed: number;
  }>;
  topUsers: Array<{
    phoneNumber: string;
    testsCount: number;
    lastTest: string;
  }>;
  hourlyDistribution: Array<{
    hour: number;
    count: number;
  }>;
}

export default function AnalyticsPage() {
  const [data, setData] = useState<AnalyticsData>({
    totalTests: 0,
    successfulTests: 0,
    failedTests: 0,
    rateLimited: 0,
    uniqueUsers: 0,
    dailyStats: [],
    topUsers: [],
    hourlyDistribution: []
  });
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('7d');

  const fetchAnalytics = async () => {
    try {
      setLoading(true);
      
      // Simular dados para demonstração
      const mockData: AnalyticsData = {
        totalTests: 247,
        successfulTests: 198,
        failedTests: 31,
        rateLimited: 18,
        uniqueUsers: 89,
        dailyStats: [
          { date: '2025-09-24', tests: 35, success: 28, failed: 7 },
          { date: '2025-09-25', tests: 42, success: 35, failed: 7 },
          { date: '2025-09-26', tests: 38, success: 30, failed: 8 },
          { date: '2025-09-27', tests: 45, success: 38, failed: 7 },
          { date: '2025-09-28', tests: 31, success: 25, failed: 6 },
          { date: '2025-09-29', tests: 28, success: 22, failed: 6 },
          { date: '2025-09-30', tests: 28, success: 20, failed: 8 }
        ],
        topUsers: [
          { phoneNumber: '5511999999999', testsCount: 12, lastTest: '2025-09-30T14:30:00Z' },
          { phoneNumber: '5511888888888', testsCount: 8, lastTest: '2025-09-30T13:15:00Z' },
          { phoneNumber: '5511777777777', testsCount: 6, lastTest: '2025-09-30T12:00:00Z' },
          { phoneNumber: '5511666666666', testsCount: 5, lastTest: '2025-09-30T10:45:00Z' },
          { phoneNumber: '5511555555555', testsCount: 4, lastTest: '2025-09-30T09:30:00Z' }
        ],
        hourlyDistribution: [
          { hour: 8, count: 5 }, { hour: 9, count: 12 }, { hour: 10, count: 18 },
          { hour: 11, count: 25 }, { hour: 12, count: 20 }, { hour: 13, count: 28 },
          { hour: 14, count: 35 }, { hour: 15, count: 32 }, { hour: 16, count: 28 },
          { hour: 17, count: 22 }, { hour: 18, count: 18 }, { hour: 19, count: 15 },
          { hour: 20, count: 12 }, { hour: 21, count: 8 }, { hour: 22, count: 5 }
        ]
      };

      await new Promise(resolve => setTimeout(resolve, 500)); // Simular delay
      setData(mockData);
    } catch (error) {
      console.error('Erro ao buscar analytics:', error);
      toast.error('Erro ao carregar dados de analytics');
    } finally {
      setLoading(false);
    }
  };

  const formatPhoneNumber = (phone: string) => {
    if (phone.length === 13 && phone.startsWith('55')) {
      return `+55 (${phone.slice(2, 4)}) ${phone.slice(4, 9)}-${phone.slice(9)}`;
    }
    return phone;
  };

  const calculateSuccessRate = () => {
    if (data.totalTests === 0) return 0;
    return Math.round((data.successfulTests / data.totalTests) * 100);
  };

  const getMaxCount = () => {
    return Math.max(...data.hourlyDistribution.map(h => h.count), 1);
  };

  useEffect(() => {
    fetchAnalytics();
  }, [period]);

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <BarChart3 className="h-8 w-8 text-primary" />
            Analytics
          </h1>
          <p className="text-muted-foreground mt-2">
            Análise detalhada do uso do sistema
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex gap-2">
            {['7d', '30d', '90d'].map((p) => (
              <Button
                key={p}
                variant={period === p ? "default" : "outline"}
                size="sm"
                onClick={() => setPeriod(p)}
              >
                {p === '7d' ? '7 dias' : p === '30d' ? '30 dias' : '90 dias'}
              </Button>
            ))}
          </div>
          <Button onClick={fetchAnalytics} disabled={loading}>
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
        </div>
      </div>

      {/* Estatísticas Principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Testes</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalTests}</div>
            <p className="text-xs text-muted-foreground">
              Últimos {period === '7d' ? '7 dias' : period === '30d' ? '30 dias' : '90 dias'}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Taxa de Sucesso</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{calculateSuccessRate()}%</div>
            <p className="text-xs text-muted-foreground">
              {data.successfulTests} de {data.totalTests} testes
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Usuários Únicos</CardTitle>
            <Users className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{data.uniqueUsers}</div>
            <p className="text-xs text-muted-foreground">
              Usuários ativos
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Erros</CardTitle>
            <Activity className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{data.failedTests}</div>
            <p className="text-xs text-muted-foreground">
              {Math.round((data.failedTests / data.totalTests) * 100)}% dos testes
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rate Limit</CardTitle>
            <Activity className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{data.rateLimited}</div>
            <p className="text-xs text-muted-foreground">
              Bloqueios aplicados
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Gráfico de Distribuição por Hora */}
        <Card>
          <CardHeader>
            <CardTitle>Distribuição por Hora</CardTitle>
            <CardDescription>
              Horários de maior atividade
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">
                <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2" />
                <p>Carregando...</p>
              </div>
            ) : (
              <div className="space-y-2">
                {data.hourlyDistribution.map((item) => (
                  <div key={item.hour} className="flex items-center gap-3">
                    <span className="text-sm font-mono w-8">
                      {item.hour.toString().padStart(2, '0')}h
                    </span>
                    <div className="flex-1 bg-gray-200 rounded-full h-2 relative">
                      <div
                        className="bg-primary h-2 rounded-full transition-all duration-500"
                        style={{ 
                          width: `${(item.count / getMaxCount()) * 100}%` 
                        }}
                      ></div>
                    </div>
                    <span className="text-sm font-medium w-8 text-right">
                      {item.count}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Top Usuários */}
        <Card>
          <CardHeader>
            <CardTitle>Top Usuários</CardTitle>
            <CardDescription>
              Usuários mais ativos
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">
                <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2" />
                <p>Carregando...</p>
              </div>
            ) : (
              <div className="space-y-3">
                {data.topUsers.map((user, index) => (
                  <div key={user.phoneNumber} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-medium">
                          {formatPhoneNumber(user.phoneNumber)}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Último teste: {new Date(user.lastTest).toLocaleString('pt-BR')}
                        </p>
                      </div>
                    </div>
                    <Badge variant="secondary">
                      {user.testsCount} testes
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Estatísticas Diárias */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-purple-500" />
            Atividade Diária
          </CardTitle>
          <CardDescription>
            Testes realizados por dia
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2" />
              <p>Carregando...</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <div className="grid grid-cols-7 gap-4 min-w-full">
                {data.dailyStats.map((day) => (
                  <div key={day.date} className="text-center p-3 border rounded-lg">
                    <div className="text-sm text-muted-foreground mb-2">
                      {new Date(day.date).toLocaleDateString('pt-BR', { 
                        weekday: 'short',
                        day: '2-digit',
                        month: '2-digit'
                      })}
                    </div>
                    <div className="text-2xl font-bold mb-1">{day.tests}</div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-center gap-1">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-xs text-green-600">{day.success}</span>
                      </div>
                      <div className="flex items-center justify-center gap-1">
                        <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                        <span className="text-xs text-red-600">{day.failed}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
