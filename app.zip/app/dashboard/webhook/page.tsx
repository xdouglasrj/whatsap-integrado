
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  Webhook, 
  Zap, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Copy, 
  RefreshCw,
  Activity,
  AlertTriangle
} from "lucide-react";
import { toast } from "sonner";

interface WebhookLog {
  id: string;
  phoneNumber: string;
  message: string;
  action: string;
  status: string;
  response: string | null;
  errorMessage: string | null;
  createdAt: string;
}

interface WebhookStats {
  total: number;
  success: number;
  error: number;
  rateLimited: number;
  uniqueUsers: number;
}

export default function WebhookPage() {
  const [logs, setLogs] = useState<WebhookLog[]>([]);
  const [stats, setStats] = useState<WebhookStats>({
    total: 0,
    success: 0,
    error: 0,
    rateLimited: 0,
    uniqueUsers: 0
  });
  const [loading, setLoading] = useState(true);
  const [testPhoneNumber, setTestPhoneNumber] = useState("");
  const [testMessage, setTestMessage] = useState("quero teste");
  const [testing, setTesting] = useState(false);

  const webhookUrl = `${typeof window !== 'undefined' ? window.location.origin : ''}/api/webhook/whatsapp`;

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Buscar logs recentes
      const logsResponse = await fetch('/api/webhook/logs?limit=50');
      const logsData = await logsResponse.json();
      
      if (logsData.success) {
        setLogs(logsData.logs);
        setStats(logsData.stats);
      }
    } catch (error) {
      console.error('Erro ao buscar dados:', error);
      toast.error('Erro ao carregar dados do webhook');
    } finally {
      setLoading(false);
    }
  };

  const testWebhook = async () => {
    if (!testPhoneNumber.trim()) {
      toast.error('Digite um número de telefone para o teste');
      return;
    }

    setTesting(true);
    try {
      const response = await fetch('/api/webhook/whatsapp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: testPhoneNumber.replace(/\D/g, ''),
          body: testMessage,
        }),
      });

      const result = await response.json();
      
      if (result.success) {
        toast.success('Webhook testado com sucesso!');
        if (result.action === 'test_generated') {
          toast.info('Teste IPTV gerado com sucesso!');
        }
      } else {
        toast.error(`Erro no webhook: ${result.error}`);
      }

      // Atualizar dados após o teste
      setTimeout(fetchData, 1000);

    } catch (error) {
      console.error('Erro no teste do webhook:', error);
      toast.error('Erro ao testar webhook');
    } finally {
      setTesting(false);
    }
  };

  const copyWebhookUrl = () => {
    navigator.clipboard.writeText(webhookUrl);
    toast.success('URL do webhook copiada!');
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'success':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle2 className="w-3 h-3 mr-1" />Sucesso</Badge>;
      case 'error':
        return <Badge className="bg-red-100 text-red-800"><XCircle className="w-3 h-3 mr-1" />Erro</Badge>;
      case 'rate_limited':
        return <Badge className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Limitado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatPhoneNumber = (phone: string) => {
    if (phone.length === 13 && phone.startsWith('55')) {
      return `+55 (${phone.slice(2, 4)}) ${phone.slice(4, 9)}-${phone.slice(9)}`;
    }
    return phone;
  };

  useEffect(() => {
    // Delay inicial para evitar problemas de hidratação
    const timer = setTimeout(() => {
      fetchData();
    }, 100);
    
    // Auto-refresh a cada 30 segundos
    const interval = setInterval(fetchData, 30000);
    
    return () => {
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Webhook className="h-8 w-8 text-primary" />
            Webhook WhatsApp
          </h1>
          <p className="text-muted-foreground mt-2">
            Monitore e configure o webhook de integração com WhatsApp
          </p>
        </div>
        
        <Button onClick={fetchData} disabled={loading}>
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Atualizar
        </Button>
      </div>

      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sucessos</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.success}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Erros</CardTitle>
            <XCircle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.error}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Limitados</CardTitle>
            <Clock className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.rateLimited}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Usuários Únicos</CardTitle>
            <Activity className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.uniqueUsers}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="logs" className="w-full">
        <TabsList>
          <TabsTrigger value="logs">Logs Recentes</TabsTrigger>
          <TabsTrigger value="config">Configuração</TabsTrigger>
          <TabsTrigger value="test">Testar Webhook</TabsTrigger>
        </TabsList>

        <TabsContent value="logs">
          <Card>
            <CardHeader>
              <CardTitle>Logs de Atividade</CardTitle>
              <CardDescription>
                Últimas 50 interações via webhook
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">
                  <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2" />
                  <p>Carregando logs...</p>
                </div>
              ) : logs.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Webhook className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Nenhum log encontrado</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {logs.map((log) => (
                    <div key={log.id} className="border rounded-lg p-4 space-y-2">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{formatPhoneNumber(log.phoneNumber)}</span>
                          {getStatusBadge(log.status)}
                        </div>
                        <span className="text-sm text-muted-foreground">
                          {new Date(log.createdAt).toLocaleString('pt-BR')}
                        </span>
                      </div>
                      
                      <div className="text-sm">
                        <strong>Mensagem:</strong> {log.message}
                      </div>
                      
                      {log.response && (
                        <div className="text-sm bg-green-50 p-2 rounded">
                          <strong>Resposta:</strong> {log.response.substring(0, 200)}
                          {log.response.length > 200 && '...'}
                        </div>
                      )}
                      
                      {log.errorMessage && (
                        <div className="text-sm bg-red-50 p-2 rounded text-red-800">
                          <strong>Erro:</strong> {log.errorMessage}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="config">
          <Card>
            <CardHeader>
              <CardTitle>Configuração do Webhook</CardTitle>
              <CardDescription>
                URL e configurações do webhook para WhatsApp
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="webhook-url">URL do Webhook</Label>
                <div className="flex gap-2 mt-1">
                  <Input 
                    id="webhook-url"
                    value={webhookUrl} 
                    readOnly 
                    className="font-mono text-sm"
                  />
                  <Button variant="outline" onClick={copyWebhookUrl}>
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  Use esta URL na configuração do webhook do seu provedor de WhatsApp
                </p>
              </div>

              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Configuração Necessária</AlertTitle>
                <AlertDescription>
                  Para usar este webhook, configure as seguintes variáveis de ambiente:
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li><code>WHATSAPP_VERIFY_TOKEN</code> - Token de verificação</li>
                    <li><code>DATABASE_URL</code> - String de conexão do banco de dados</li>
                  </ul>
                </AlertDescription>
              </Alert>

              <div className="space-y-2">
                <h4 className="font-medium">Palavras-chave configuradas:</h4>
                <div className="flex flex-wrap gap-2">
                  {['teste', 'trial', 'demo', 'testar', 'test', 'quero teste', 'solicitar teste'].map((trigger) => (
                    <Badge key={trigger} variant="secondary">{trigger}</Badge>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium">Rate Limiting:</h4>
                <p className="text-sm text-muted-foreground">
                  1 teste por usuário a cada 10 minutos
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="test">
          <Card>
            <CardHeader>
              <CardTitle>Testar Webhook</CardTitle>
              <CardDescription>
                Simule uma solicitação de teste via WhatsApp
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="phone">Número de Telefone (apenas números)</Label>
                <Input
                  id="phone"
                  type="text"
                  placeholder="5511999999999"
                  value={testPhoneNumber}
                  onChange={(e) => setTestPhoneNumber(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Mensagem</Label>
                <Textarea
                  id="message"
                  placeholder="quero teste"
                  value={testMessage}
                  onChange={(e) => setTestMessage(e.target.value)}
                />
              </div>

              <Button onClick={testWebhook} disabled={testing}>
                {testing ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Testando...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Enviar Teste
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
