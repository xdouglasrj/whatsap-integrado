
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Smartphone, 
  Zap, 
  CheckCircle2, 
  ExternalLink, 
  AlertTriangle,
  Copy,
  Bot,
  Loader2
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function WhatsAppSetupPage() {
  const { toast } = useToast();
  const [currentTab, setCurrentTab] = useState("botstar");

  // Estados para Twilio
  const [twilioLoading, setTwilioLoading] = useState(false);
  const [twilioData, setTwilioData] = useState({
    account_sid: '',
    auth_token: '',
    whatsapp_number: ''
  });

  // Estados para Meta
  const [metaLoading, setMetaLoading] = useState(false);
  const [metaData, setMetaData] = useState({
    access_token: '',
    phone_number_id: '',
    verify_token: ''
  });

  // Carregar dados existentes
  useEffect(() => {
    const loadExistingData = async () => {
      try {
        // Carregar dados do Twilio
        const twilioResponse = await fetch('/api/dashboard/twilio-config');
        if (twilioResponse.ok) {
          const twilioConfig = await twilioResponse.json();
          setTwilioData({
            account_sid: twilioConfig.account_sid || '',
            auth_token: twilioConfig.auth_token || '',
            whatsapp_number: twilioConfig.whatsapp_number || ''
          });
        }

        // Carregar dados do Meta
        const metaResponse = await fetch('/api/dashboard/whatsapp-config');
        if (metaResponse.ok) {
          const metaConfig = await metaResponse.json();
          setMetaData({
            access_token: metaConfig.access_token || '',
            phone_number_id: metaConfig.phone_number_id || '',
            verify_token: metaConfig.verify_token || ''
          });
        }
      } catch (error) {
        console.error('Erro ao carregar configurações:', error);
      }
    };

    loadExistingData();
  }, []);

  // Função para salvar configuração Twilio
  const handleSaveTwilio = async () => {
    setTwilioLoading(true);
    try {
      const response = await fetch('/api/dashboard/twilio-config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          enabled: true,
          ...twilioData
        })
      });

      const result = await response.json();

      if (response.ok) {
        toast({
          title: "Sucesso!",
          description: "Configuração Twilio salva com sucesso",
        });
      } else {
        throw new Error(result.error || 'Erro ao salvar');
      }
    } catch (error) {
      toast({
        title: "Erro!",
        description: error instanceof Error ? error.message : "Erro ao salvar configuração",
        variant: "destructive",
      });
    } finally {
      setTwilioLoading(false);
    }
  };

  // Função para salvar configuração Meta
  const handleSaveMeta = async () => {
    setMetaLoading(true);
    try {
      const response = await fetch('/api/dashboard/whatsapp-config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          enabled: true,
          ...metaData
        })
      });

      const result = await response.json();

      if (response.ok) {
        toast({
          title: "Sucesso!",
          description: "Configuração Meta salva com sucesso",
        });
      } else {
        throw new Error(result.error || 'Erro ao salvar');
      }
    } catch (error) {
      toast({
        title: "Erro!",
        description: error instanceof Error ? error.message : "Erro ao salvar configuração",
        variant: "destructive",
      });
    } finally {
      setMetaLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copiado!",
      description: "URL copiada para a área de transferência",
    });
  };

  return (
    <div className="container mx-auto p-6 space-y-8">
      <div className="flex items-center space-x-3">
        <Smartphone className="h-8 w-8 text-primary" />
        <div>
          <h1 className="text-3xl font-bold">Configuração WhatsApp</h1>
          <p className="text-gray-600">Escolha a melhor opção para integrar com WhatsApp</p>
        </div>
      </div>

      <Alert>
        <CheckCircle2 className="h-4 w-4" />
        <AlertDescription>
          <strong>Sistema funcionando!</strong> Seu webhook já está ativo em: 
          <code className="ml-2 bg-gray-100 px-2 py-1 rounded">https://your-domain.com/api/webhook/whatsapp</code>
        </AlertDescription>
      </Alert>

      <Tabs value={currentTab} onValueChange={setCurrentTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="botstar">
            <Bot className="h-4 w-4 mr-2" />
            BotStar (Recomendado)
          </TabsTrigger>
          <TabsTrigger value="twilio">
            <Zap className="h-4 w-4 mr-2" />
            Twilio WhatsApp
          </TabsTrigger>
          <TabsTrigger value="meta">
            <Smartphone className="h-4 w-4 mr-2" />
            Meta Business
          </TabsTrigger>
        </TabsList>

        {/* BotStar Tab */}
        <TabsContent value="botstar" className="space-y-6">
          <Card className="border-green-200 bg-green-50">
            <CardHeader>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="h-6 w-6 text-green-600" />
                <CardTitle className="text-green-800">BotStar - Configuração Simples</CardTitle>
              </div>
              <CardDescription className="text-green-700">
                Você já tem BotStar funcionando! Vamos otimizar a integração.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium">1. URL do Webhook</Label>
                <div className="flex mt-1">
                  <Input 
                    value="https://your-domain.com/api/webhook/whatsapp"
                    readOnly 
                    className="mr-2"
                  />
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => copyToClipboard("https://your-domain.com/api/webhook/whatsapp")}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Configuração no BotStar:</strong>
                  <ol className="mt-2 space-y-1 text-sm">
                    <li>1. Vá para <strong>Automation → Webhook</strong></li>
                    <li>2. Cole a URL acima no campo <strong>Webhook URL</strong></li>
                    <li>3. Em <strong>Quick Response</strong>, use: <code>{'{{webhook.response}}'}</code></li>
                    <li>4. Configure palavras-chave como: <strong>"teste", "trial", "demo"</strong></li>
                  </ol>
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-2 gap-4">
                <Button variant="outline" className="w-full">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Abrir BotStar
                </Button>
                <Button variant="outline" className="w-full">
                  <CheckCircle2 className="h-4 w-4 mr-2" />
                  Testar Webhook
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Twilio Tab */}
        <TabsContent value="twilio" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Zap className="h-6 w-6 text-primary" />
                <span>Twilio WhatsApp API</span>
              </CardTitle>
              <CardDescription>
                Alternativa mais simples que Meta Business API
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <AlertDescription>
                  <strong>Por que Twilio é mais fácil:</strong>
                  <ul className="mt-2 space-y-1 text-sm">
                    <li>• Registro mais simples</li>
                    <li>• Documentação melhor</li>
                    <li>• Suporte em português</li>
                    <li>• Setup em 10 minutos</li>
                  </ul>
                </AlertDescription>
              </Alert>

              <div className="space-y-3">
                <div>
                  <Label htmlFor="twilio_sid">Account SID</Label>
                  <Input 
                    id="twilio_sid" 
                    placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                    value={twilioData.account_sid}
                    onChange={(e) => setTwilioData(prev => ({ ...prev, account_sid: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="twilio_token">Auth Token</Label>
                  <Input 
                    id="twilio_token" 
                    type="password"
                    placeholder="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                    value={twilioData.auth_token}
                    onChange={(e) => setTwilioData(prev => ({ ...prev, auth_token: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="twilio_whatsapp">Número WhatsApp</Label>
                  <Input 
                    id="twilio_whatsapp" 
                    placeholder="whatsapp:+14155238886"
                    value={twilioData.whatsapp_number}
                    onChange={(e) => setTwilioData(prev => ({ ...prev, whatsapp_number: e.target.value }))}
                  />
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-800 mb-2">Como conseguir credenciais Twilio:</h4>
                <ol className="text-sm text-blue-700 space-y-1">
                  <li>1. Vá para <a href="https://twilio.com" className="underline" target="_blank">twilio.com</a></li>
                  <li>2. Crie conta gratuita</li>
                  <li>3. Ative WhatsApp Sandbox</li>
                  <li>4. Copie Account SID e Auth Token</li>
                </ol>
              </div>

              <Button 
                className="w-full" 
                onClick={handleSaveTwilio}
                disabled={twilioLoading}
              >
                {twilioLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Salvar Configuração Twilio
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Meta Business Tab */}
        <TabsContent value="meta" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Smartphone className="h-6 w-6 text-primary" />
                <span>Meta Business API</span>
              </CardTitle>
              <CardDescription>
                WhatsApp Business API oficial (processo mais complexo)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Processo complexo!</strong> Pode levar dias para aprovação e requer verificação de negócio.
                </AlertDescription>
              </Alert>

              <div className="space-y-3">
                <div>
                  <Label htmlFor="meta_token">Access Token</Label>
                  <Input 
                    id="meta_token" 
                    type="password"
                    placeholder="EAAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                    value={metaData.access_token}
                    onChange={(e) => setMetaData(prev => ({ ...prev, access_token: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="meta_phone_id">Phone Number ID</Label>
                  <Input 
                    id="meta_phone_id" 
                    placeholder="1234567890123456"
                    value={metaData.phone_number_id}
                    onChange={(e) => setMetaData(prev => ({ ...prev, phone_number_id: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="meta_verify_token">Verify Token</Label>
                  <Input 
                    id="meta_verify_token" 
                    placeholder="meu_token_secreto"
                    value={metaData.verify_token}
                    onChange={(e) => setMetaData(prev => ({ ...prev, verify_token: e.target.value }))}
                  />
                </div>
              </div>

              <div className="bg-yellow-50 p-4 rounded-lg">
                <h4 className="font-semibold text-yellow-800 mb-2">Passos para Meta Business API:</h4>
                <ol className="text-sm text-yellow-700 space-y-1">
                  <li>1. Criar conta Meta Business</li>
                  <li>2. Verificar negócio (pode levar dias)</li>
                  <li>3. Criar app no Meta for Developers</li>
                  <li>4. Adicionar produto WhatsApp</li>
                  <li>5. Configurar webhook</li>
                  <li>6. Obter token permanente</li>
                </ol>
              </div>

              <Button 
                className="w-full" 
                variant="secondary"
                onClick={handleSaveMeta}
                disabled={metaLoading}
              >
                {metaLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Salvar Configuração Meta
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Recommendation */}
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="pt-6">
          <h3 className="font-semibold text-lg mb-2">💡 Recomendação</h3>
          <p className="text-gray-600 mb-4">
            Como você já tem <strong>BotStar funcionando</strong>, recomendamos continuar usando essa integração. 
            É mais simples e já está configurada!
          </p>
          <p className="text-sm text-gray-500">
            Se precisar de mais controle no futuro, considere migrar para Twilio (mais fácil que Meta).
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
