
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Smartphone, 
  Zap, 
  Shield, 
  BarChart3, 
  Settings,
  ArrowRight 
} from "lucide-react";

export default async function HomePage() {
  const session = await getServerSession(authOptions);

  if (session) {
    redirect('/dashboard');
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-16 max-w-6xl">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="flex justify-center items-center mb-6">
            <div className="flex items-center space-x-3">
              <Smartphone className="h-12 w-12 text-primary" />
              <Zap className="h-8 w-8 text-primary" />
              <div className="h-12 w-12 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-white font-bold text-lg">TV</span>
              </div>
            </div>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            IPTV WhatsApp
            <span className="text-primary block">Integration</span>
          </h1>
          
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
            Sistema completo de integração entre WhatsApp e sites de IPTV. 
            Gere testes automaticamente via webhook com controle total de rate limiting e logs detalhados.
          </p>
          
          <Link href="/login">
            <Button size="lg" className="gap-2 px-8 py-3 text-lg">
              Acessar Sistema
              <ArrowRight className="h-5 w-5" />
            </Button>
          </Link>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card className="bg-white/50 backdrop-blur border-0 shadow-lg">
            <CardHeader className="text-center">
              <Zap className="h-10 w-10 text-primary mx-auto mb-2" />
              <CardTitle className="text-lg">Webhook API</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">
                Endpoint robusto para receber solicitações do WhatsApp e processar automaticamente
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-white/50 backdrop-blur border-0 shadow-lg">
            <CardHeader className="text-center">
              <Settings className="h-10 w-10 text-primary mx-auto mb-2" />
              <CardTitle className="text-lg">Múltiplos Sites</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">
                Configure diferentes sites de IPTV com autenticação personalizada
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-white/50 backdrop-blur border-0 shadow-lg">
            <CardHeader className="text-center">
              <Shield className="h-10 w-10 text-primary mx-auto mb-2" />
              <CardTitle className="text-lg">Rate Limiting</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">
                Controle inteligente de frequência de solicitações por usuário
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-white/50 backdrop-blur border-0 shadow-lg">
            <CardHeader className="text-center">
              <BarChart3 className="h-10 w-10 text-primary mx-auto mb-2" />
              <CardTitle className="text-lg">Logs & Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">
                Monitoramento completo com estatísticas e logs detalhados
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        {/* Integration Example */}
        <Card className="bg-white/70 backdrop-blur border-0 shadow-xl">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl mb-2">Como Funciona</CardTitle>
            <CardDescription className="text-lg">
              Fluxo simples e automatizado de integração
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-8 mt-8">
              <div className="text-center">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <span className="text-primary font-bold text-xl">1</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">Recebe Solicitação</h3>
                <p className="text-gray-600">WhatsApp envia webhook para o sistema com número do usuário</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <span className="text-primary font-bold text-xl">2</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">Gera Teste IPTV</h3>
                <p className="text-gray-600">Sistema conecta com site IPTV e gera credenciais automaticamente</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <span className="text-primary font-bold text-xl">3</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">Retorna Resposta</h3>
                <p className="text-gray-600">Credenciais formatadas são enviadas de volta para o WhatsApp</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
