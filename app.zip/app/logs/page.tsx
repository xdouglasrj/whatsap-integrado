"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Activity } from "lucide-react";
import Link from "next/link";

export default function LogsPage() {
  return (
    <div className="container mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-6 w-6" />
            Logs do Sistema
          </CardTitle>
          <CardDescription>
            Esta página foi migrada para o novo dashboard
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-4">
            Os logs agora estão integrados no dashboard principal com funcionalidades aprimoradas.
            Acesse através da seção de Webhook para ver logs detalhados.
          </p>
          
          <Link href="/dashboard/webhook">
            <Button>
              Ver Logs no Dashboard
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}