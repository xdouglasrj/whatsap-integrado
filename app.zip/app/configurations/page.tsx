"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Settings } from "lucide-react";
import Link from "next/link";

export default function ConfigurationsPage() {
  return (
    <div className="container mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-6 w-6" />
            Configurações IPTV
          </CardTitle>
          <CardDescription>
            Esta página foi migrada para o novo dashboard
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-4">
            O gerenciamento de configurações IPTV agora está integrado no dashboard principal.
            Todas as configurações estão disponíveis através da interface unificada.
          </p>
          
          <Link href="/dashboard">
            <Button>
              Ir para Dashboard
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}