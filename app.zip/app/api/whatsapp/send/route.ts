
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import twilio from 'twilio';

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    const { to, message, provider = 'twilio' } = await request.json();

    if (!to || !message) {
      return NextResponse.json({ 
        error: 'Campos "to" e "message" são obrigatórios' 
      }, { status: 400 });
    }

    if (provider === 'twilio') {
      // Verificar se as credenciais Twilio estão configuradas
      const accountSid = process.env.TWILIO_ACCOUNT_SID;
      const authToken = process.env.TWILIO_AUTH_TOKEN;
      const twilioWhatsApp = process.env.TWILIO_WHATSAPP_NUMBER;

      if (!accountSid || !authToken || !twilioWhatsApp) {
        return NextResponse.json({
          error: 'Credenciais Twilio não configuradas',
          missing: {
            accountSid: !accountSid,
            authToken: !authToken, 
            whatsappNumber: !twilioWhatsApp
          }
        }, { status: 400 });
      }

      // Enviar via Twilio
      const client = twilio(accountSid, authToken);
      
      const result = await client.messages.create({
        body: message,
        from: twilioWhatsApp,
        to: to.startsWith('whatsapp:') ? to : `whatsapp:${to}`
      });

      return NextResponse.json({
        success: true,
        provider: 'twilio',
        messageId: result.sid,
        status: result.status
      });

    } else if (provider === 'meta') {
      // Meta WhatsApp Business API
      const accessToken = process.env.WHATSAPP_ACCESS_TOKEN;
      const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;

      if (!accessToken || !phoneNumberId) {
        return NextResponse.json({
          error: 'Credenciais Meta WhatsApp não configuradas'
        }, { status: 400 });
      }

      const response = await fetch(`https://graph.facebook.com/v18.0/${phoneNumberId}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: to.replace(/\D/g, ''), // Apenas números
          text: { body: message }
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(`Meta API error: ${result.error?.message || 'Unknown error'}`);
      }

      return NextResponse.json({
        success: true,
        provider: 'meta',
        messageId: result.messages[0].id
      });
    }

    return NextResponse.json({
      error: 'Provedor não suportado'
    }, { status: 400 });

  } catch (error: any) {
    console.error('Erro ao enviar mensagem WhatsApp:', error);
    
    return NextResponse.json({
      error: 'Erro ao enviar mensagem',
      details: error.message
    }, { status: 500 });
  }
}
