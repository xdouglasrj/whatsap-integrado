// API Keys endpoint deprecated - functionality moved to dashboard
import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    message: "Este endpoint foi descontinuado. Use o dashboard para gerenciar configurações.",
    status: "deprecated"
  });
}

export async function POST() {
  return NextResponse.json({
    message: "Este endpoint foi descontinuado. Use o dashboard para gerenciar configurações.",
    status: "deprecated"
  });
}