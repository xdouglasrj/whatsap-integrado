
import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET() {
  try {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    // Estatísticas gerais
    const totalStats = await prisma.webhookLog.aggregate({
      _count: { id: true }
    });

    const statusStats = await prisma.webhookLog.groupBy({
      by: ['status'],
      _count: { status: true }
    });

    const uniqueUsers = await prisma.webhookLog.findMany({
      select: { phoneNumber: true },
      distinct: ['phoneNumber']
    });

    // Estatísticas de hoje
    const todayStats = await prisma.webhookLog.groupBy({
      by: ['status'],
      where: {
        createdAt: { gte: today }
      },
      _count: { status: true }
    });

    // Atividade recente
    const recentActivity = await prisma.webhookLog.findMany({
      select: {
        id: true,
        phoneNumber: true,
        action: true,
        status: true,
        createdAt: true
      },
      orderBy: { createdAt: 'desc' },
      take: 10
    });

    // Formatar estatísticas
    const stats = {
      total: totalStats._count.id,
      success: statusStats.find(s => s.status === 'success')?._count.status || 0,
      error: statusStats.find(s => s.status === 'error')?._count.status || 0,
      rateLimited: statusStats.find(s => s.status === 'rate_limited')?._count.status || 0,
      uniqueUsers: uniqueUsers.length,
      todayStats: {
        total: todayStats.reduce((acc, curr) => acc + curr._count.status, 0),
        success: todayStats.find(s => s.status === 'success')?._count.status || 0,
        error: todayStats.find(s => s.status === 'error')?._count.status || 0,
      },
      recentActivity
    };

    return NextResponse.json({ success: true, stats });

  } catch (error) {
    console.error('[DASHBOARD STATS] Erro:', error);
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido'
    }, { status: 500 });
  }
}
