
import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { access_token, phone_number_id } = body;

    if (!access_token || !phone_number_id) {
      return NextResponse.json({
        success: false,
        message: 'Access Token e Phone Number ID são obrigatórios'
      }, { status: 400 });
    }

    // Testar conexão com a API do WhatsApp
    const testUrl = `https://graph.facebook.com/v17.0/${phone_number_id}`;
    
    console.log('[WHATSAPP-TEST] Testando conexão:', testUrl);

    const response = await fetch(testUrl, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${access_token}`,
        'Content-Type': 'application/json',
      }
    });

    const result = await response.json();
    console.log('[WHATSAPP-TEST] Resposta da API:', result);

    if (response.ok) {
      // Verificar se a resposta contém informações válidas do número
      if (result.id && result.display_phone_number) {
        return NextResponse.json({
          success: true,
          message: `Conexão estabelecida com sucesso! Número: ${result.display_phone_number}`,
          data: {
            phone_number: result.display_phone_number,
            verified_name: result.verified_name || 'Não verificado',
            status: result.status || 'Ativo'
          }
        });
      } else {
        return NextResponse.json({
          success: false,
          message: 'Conexão estabelecida, mas dados do número não encontrados'
        });
      }
    } else {
      // Interpretar erros comuns
      let errorMessage = 'Erro desconhecido';
      
      if (result.error) {
        const errorCode = result.error.code;
        const errorText = result.error.message;
        
        switch (errorCode) {
          case 190:
            errorMessage = 'Access Token inválido ou expirado';
            break;
          case 100:
            errorMessage = 'Phone Number ID inválido';
            break;
          default:
            errorMessage = `${errorText} (Código: ${errorCode})`;
        }
      } else if (response.status === 404) {
        errorMessage = 'Phone Number ID não encontrado';
      } else if (response.status === 401) {
        errorMessage = 'Access Token não autorizado';
      }

      return NextResponse.json({
        success: false,
        message: errorMessage
      });
    }

  } catch (error) {
    console.error('[WHATSAPP-TEST] Erro no teste:', error);
    
    const errorMessage = error instanceof Error ? error.message : 'Erro de conexão';
    
    return NextResponse.json({
      success: false,
      message: `Erro de conexão: ${errorMessage}`
    }, { status: 500 });
  }
}
