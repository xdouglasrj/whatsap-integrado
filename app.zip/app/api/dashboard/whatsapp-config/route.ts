
import { NextRequest, NextResponse } from 'next/server';
import { writeFileSync, readFileSync } from 'fs';
import { join } from 'path';

// Função para ler o arquivo .env
function readEnvFile(): Record<string, string> {
  try {
    const envPath = join(process.cwd(), '.env');
    const content = readFileSync(envPath, 'utf-8');
    const env: Record<string, string> = {};
    
    content.split('\n').forEach(line => {
      const [key, ...valueParts] = line.split('=');
      if (key && valueParts.length) {
        const value = valueParts.join('=').replace(/^['"]|['"]$/g, '');
        env[key.trim()] = value;
      }
    });
    
    return env;
  } catch (error) {
    return {};
  }
}

// Função para escrever no arquivo .env
function writeEnvFile(env: Record<string, string>) {
  try {
    const envPath = join(process.cwd(), '.env');
    const content = Object.entries(env)
      .map(([key, value]) => `${key}=${value}`)
      .join('\n');
    
    writeFileSync(envPath, content);
    return true;
  } catch (error) {
    console.error('Erro ao escrever .env:', error);
    return false;
  }
}

export async function GET() {
  try {
    const env = readEnvFile();
    
    return NextResponse.json({
      enabled: env.ENABLE_DIRECT_WHATSAPP === 'true',
      access_token: env.WHATSAPP_ACCESS_TOKEN || '',
      phone_number_id: env.WHATSAPP_PHONE_NUMBER_ID || '',
      verify_token: env.WHATSAPP_VERIFY_TOKEN || ''
    });
  } catch (error) {
    console.error('Erro ao ler configuração:', error);
    return NextResponse.json(
      { error: 'Erro ao ler configuração' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { enabled, access_token, phone_number_id, verify_token } = body;

    // Validar campos obrigatórios se habilitado
    if (enabled) {
      if (!access_token || !phone_number_id) {
        return NextResponse.json(
          { error: 'Access Token e Phone Number ID são obrigatórios quando habilitado' },
          { status: 400 }
        );
      }
    }

    // Ler arquivo .env atual
    const env = readEnvFile();

    // Atualizar valores
    env.ENABLE_DIRECT_WHATSAPP = enabled ? 'true' : 'false';
    env.WHATSAPP_ACCESS_TOKEN = access_token || '';
    env.WHATSAPP_PHONE_NUMBER_ID = phone_number_id || '';
    env.WHATSAPP_VERIFY_TOKEN = verify_token || '';

    // Salvar arquivo .env
    const saved = writeEnvFile(env);
    
    if (!saved) {
      return NextResponse.json(
        { error: 'Erro ao salvar configuração' },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'Configuração salva com sucesso'
    });

  } catch (error) {
    console.error('Erro ao salvar configuração:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
