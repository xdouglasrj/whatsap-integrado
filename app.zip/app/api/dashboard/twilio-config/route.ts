
import { NextRequest, NextResponse } from 'next/server';
import { writeFileSync, readFileSync } from 'fs';
import { join } from 'path';

// Função para ler o arquivo .env
function readEnvFile(): Record<string, string> {
  try {
    const envPath = join(process.cwd(), '.env');
    const content = readFileSync(envPath, 'utf-8');
    const env: Record<string, string> = {};
    
    content.split('\n').forEach(line => {
      const [key, ...valueParts] = line.split('=');
      if (key && valueParts.length) {
        const value = valueParts.join('=').replace(/^['"]|['"]$/g, '');
        env[key.trim()] = value;
      }
    });
    
    return env;
  } catch (error) {
    return {};
  }
}

// Função para escrever no arquivo .env
function writeEnvFile(env: Record<string, string>) {
  try {
    const envPath = join(process.cwd(), '.env');
    const content = Object.entries(env)
      .map(([key, value]) => `${key}=${value}`)
      .join('\n');
    
    writeFileSync(envPath, content);
    return true;
  } catch (error) {
    console.error('Erro ao escrever .env:', error);
    return false;
  }
}

export async function GET() {
  try {
    const env = readEnvFile();
    
    return NextResponse.json({
      enabled: env.ENABLE_TWILIO_WHATSAPP === 'true',
      account_sid: env.TWILIO_ACCOUNT_SID || '',
      auth_token: env.TWILIO_AUTH_TOKEN || '',
      whatsapp_number: env.TWILIO_WHATSAPP_NUMBER || ''
    });
  } catch (error) {
    console.error('Erro ao ler configuração Twilio:', error);
    return NextResponse.json(
      { error: 'Erro ao ler configuração' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { enabled, account_sid, auth_token, whatsapp_number } = body;

    // Validar campos obrigatórios se habilitado
    if (enabled) {
      if (!account_sid || !auth_token || !whatsapp_number) {
        return NextResponse.json(
          { error: 'Account SID, Auth Token e WhatsApp Number são obrigatórios quando habilitado' },
          { status: 400 }
        );
      }

      // Validar formato do Account SID
      if (!account_sid.startsWith('AC')) {
        return NextResponse.json(
          { error: 'Account SID deve começar com "AC"' },
          { status: 400 }
        );
      }

      // Validar formato do número WhatsApp
      if (!whatsapp_number.startsWith('whatsapp:+')) {
        return NextResponse.json(
          { error: 'Número WhatsApp deve estar no formato "whatsapp:+1234567890"' },
          { status: 400 }
        );
      }
    }

    // Ler arquivo .env atual
    const env = readEnvFile();

    // Atualizar valores
    env.ENABLE_TWILIO_WHATSAPP = enabled ? 'true' : 'false';
    env.TWILIO_ACCOUNT_SID = account_sid || '';
    env.TWILIO_AUTH_TOKEN = auth_token || '';
    env.TWILIO_WHATSAPP_NUMBER = whatsapp_number || '';

    // Salvar arquivo .env
    const saved = writeEnvFile(env);
    
    if (!saved) {
      return NextResponse.json(
        { error: 'Erro ao salvar configuração' },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'Configuração Twilio salva com sucesso'
    });

  } catch (error) {
    console.error('Erro ao salvar configuração Twilio:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
