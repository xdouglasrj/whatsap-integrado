// Logs endpoint deprecated - functionality moved to webhook logs
import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    message: "Este endpoint foi migrado para /api/webhook/logs",
    new_endpoint: "/api/webhook/logs",
    status: "deprecated"
  });
}