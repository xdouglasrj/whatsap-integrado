
import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Force dynamic rendering
export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '50');

    // Buscar logs recentes
    const logs = await prisma.webhookLog.findMany({
      orderBy: {
        createdAt: 'desc'
      },
      take: limit
    });

    // Calcular estatísticas
    const stats = await prisma.webhookLog.aggregate({
      _count: {
        id: true,
      },
    });

    const successCount = await prisma.webhookLog.count({
      where: { status: 'success' }
    });

    const errorCount = await prisma.webhookLog.count({
      where: { status: 'error' }
    });

    const rateLimitedCount = await prisma.webhookLog.count({
      where: { status: 'rate_limited' }
    });

    const uniqueUsers = await prisma.webhookLog.groupBy({
      by: ['phoneNumber'],
      _count: {
        phoneNumber: true,
      }
    });

    return NextResponse.json({
      success: true,
      logs,
      stats: {
        total: stats._count.id,
        success: successCount,
        error: errorCount,
        rateLimited: rateLimitedCount,
        uniqueUsers: uniqueUsers.length,
      }
    });

  } catch (error) {
    console.error('Erro ao buscar logs:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erro interno do servidor' 
    }, { status: 500 });
  }
}
