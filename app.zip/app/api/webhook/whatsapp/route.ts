
import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { headers } from 'next/headers';

const prisma = new PrismaClient();

// Configuração do WhatsApp Business API
const WHATSAPP_CONFIG = {
  access_token: process.env.WHATSAPP_ACCESS_TOKEN || '',
  phone_number_id: process.env.WHATSAPP_PHONE_NUMBER_ID || '',
  api_url: 'https://graph.facebook.com/v17.0',
  enabled: process.env.ENABLE_DIRECT_WHATSAPP === 'true'
};

// Configuração da API IPTV
const IPTV_CONFIG = {
  api_url: process.env.IPTV_API_URL || "https://painel.best/sys/api.php",
  api_key: process.env.IPTV_API_KEY || "",
  triggers: ["teste", "trial", "demo", "testar", "test", "quero teste", "solicitar teste"],
  rate_limit_minutes: 10, // Limite de 1 teste por usuário a cada 10 minutos
};

// Template de resposta personalizado
const MESSAGE_TEMPLATE = `🎉 *Seja bem-vindo(a) à The Best!*

👤 *Usuário:* {{usuario}}
🔐 *Senha:* {{senha}}
🌐 *URL DNS:* {{dns}}
⏰ *Validade:* {{validade}}

📺 *M3U8:* {{m3u8}}

💻 *Área do cliente:* {{area_cliente}}

⚠️ *Atenção: Você pode renovar sua assinatura através da área do cliente*

━━━━━━━━━━━━━━━━━━━━━
🤖 *Sistema automático de testes*
📞 *Suporte:* Entre em contato para mais informações`;

// Verificar se mensagem contém palavra-chave para teste
function detectarSolicitacaoTeste(mensagem: string): boolean {
  const textoLower = mensagem.toLowerCase().trim();
  return IPTV_CONFIG.triggers.some(trigger => textoLower.includes(trigger.toLowerCase()));
}

// Gerar dados simulados para demonstração
function gerarDadosSimulados(): any {
  const agora = new Date();
  const validade = new Date(agora.getTime() + (24 * 60 * 60 * 1000)); // 24 horas
  const usuarioId = Math.floor(Math.random() * 90000) + 10000;
  const senhaId = Math.floor(Math.random() * 900000) + 100000;
  
  return {
    usuario: `demo${usuarioId}`,
    senha: `pass${senhaId}`,
    dns: 'http://painel.best',
    validade: validade.toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }),
    simulado: true
  };
}

// Gerar teste IPTV
async function gerarTesteIPTV(): Promise<any> {
  try {
    const url = `${IPTV_CONFIG.api_url}?action=fast_test&type=iptv&result_cb=json&api_key=${IPTV_CONFIG.api_key}`;
    
    console.log('[WEBHOOK] Chamando API IPTV:', url);
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
        'Accept-Encoding': 'gzip, deflate, br',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Cache-Control': 'max-age=0'
      },
    });

    if (!response.ok) {
      console.warn('[WEBHOOK] API IPTV indisponível, usando dados simulados');
      return gerarDadosSimulados();
    }

    const resultado = await response.json();
    console.log('[WEBHOOK] Resposta da API IPTV:', resultado);
    
    return resultado;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
    console.warn('[WEBHOOK] Erro ao conectar com API IPTV, usando dados simulados:', errorMessage);
    return gerarDadosSimulados();
  }
}

// Verificar rate limiting
async function verificarRateLimit(numeroTelefone: string): Promise<boolean> {
  const agora = new Date();
  const limiteTempo = new Date(agora.getTime() - (IPTV_CONFIG.rate_limit_minutes * 60 * 1000));

  try {
    const ultimoTeste = await prisma.webhookLog.findFirst({
      where: {
        phoneNumber: numeroTelefone,
        status: 'success',
        createdAt: {
          gte: limiteTempo
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    return ultimoTeste === null;
  } catch (error) {
    console.error('[WEBHOOK] Erro ao verificar rate limit:', error);
    return true; // Em caso de erro, permite o teste
  }
}

// Formatar mensagem de resposta
function formatarMensagem(dadosIPTV: any): string {
  const m3u8_url = `${dadosIPTV.dns}/get.php?username=${dadosIPTV.usuario}&password=${dadosIPTV.senha}&type=m3u_plus&output=ts`;
  const area_cliente_url = `http://cliente.painel.best/client?username=${dadosIPTV.usuario}&password=${dadosIPTV.senha}`;
  
  let template = MESSAGE_TEMPLATE;
  
  // Se são dados simulados, adiciona um aviso
  if (dadosIPTV.simulado) {
    template = `🔧 *MODO DEMONSTRAÇÃO* 🔧
${MESSAGE_TEMPLATE}

⚠️ *Estes são dados simulados para demonstração do sistema. Em produção, serão geradas credenciais reais.*`;
  }

  return template
    .replace('{{usuario}}', dadosIPTV.usuario || '')
    .replace('{{senha}}', dadosIPTV.senha || '')
    .replace('{{dns}}', dadosIPTV.dns || '')
    .replace('{{validade}}', dadosIPTV.validade || '')
    .replace('{{m3u8}}', m3u8_url)
    .replace('{{area_cliente}}', area_cliente_url);
}

// Enviar mensagem diretamente ao WhatsApp
async function enviarMensagemWhatsApp(numeroTelefone: string, mensagem: string): Promise<boolean> {
  if (!WHATSAPP_CONFIG.enabled || !WHATSAPP_CONFIG.access_token || !WHATSAPP_CONFIG.phone_number_id) {
    console.log('[WHATSAPP] Envio direto desabilitado ou não configurado');
    return false;
  }

  try {
    const url = `${WHATSAPP_CONFIG.api_url}/${WHATSAPP_CONFIG.phone_number_id}/messages`;
    
    const payload = {
      messaging_product: 'whatsapp',
      to: numeroTelefone,
      type: 'text',
      text: {
        body: mensagem
      }
    };

    console.log('[WHATSAPP] Enviando mensagem para:', numeroTelefone);
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${WHATSAPP_CONFIG.access_token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });

    const result = await response.json();
    
    if (response.ok) {
      console.log('[WHATSAPP] Mensagem enviada com sucesso:', result);
      return true;
    } else {
      console.error('[WHATSAPP] Erro ao enviar mensagem:', result);
      return false;
    }
    
  } catch (error) {
    console.error('[WHATSAPP] Erro ao enviar mensagem:', error);
    return false;
  }
}

// Log da atividade
async function salvarLog(data: {
  phoneNumber: string;
  message: string;
  action: string;
  status: 'success' | 'error' | 'rate_limited';
  response?: string;
  error?: string;
}) {
  try {
    await prisma.webhookLog.create({
      data: {
        phoneNumber: data.phoneNumber,
        message: data.message,
        action: data.action,
        status: data.status,
        response: data.response,
        errorMessage: data.error,
      }
    });
  } catch (error) {
    console.error('[WEBHOOK] Erro ao salvar log:', error);
  }
}

// Handler principal do webhook
export async function POST(request: NextRequest) {
  const startTime = Date.now();
  let phoneNumber = '';
  let mensagem = '';

  try {
    const headersList = headers();
    const userAgent = headersList.get('user-agent') || '';
    const contentType = headersList.get('content-type') || '';

    console.log('[WEBHOOK] Recebido:', {
      userAgent,
      contentType,
      timestamp: new Date().toISOString()
    });

    // Parse do body da requisição
    const body = await request.json();
    console.log('[WEBHOOK] Body recebido:', JSON.stringify(body, null, 2));

    // Adaptar para diferentes formatos de webhook do WhatsApp
    // Formato comum: { from: "5511999999999", body: "mensagem" }
    phoneNumber = body.from || body.phone_number || body.number || '';
    mensagem = body.body || body.message || body.text || '';

    if (!phoneNumber || !mensagem) {
      console.warn('[WEBHOOK] Dados incompletos:', { phoneNumber, mensagem });
      return NextResponse.json({
        success: false,
        error: 'Número de telefone ou mensagem não fornecidos',
        received: { phoneNumber, mensagem }
      }, { status: 400 });
    }

    // Limpar e formatar número de telefone
    phoneNumber = phoneNumber.replace(/\D/g, '');
    
    console.log('[WEBHOOK] Processando:', { 
      phoneNumber, 
      mensagem: mensagem.substring(0, 50) + (mensagem.length > 50 ? '...' : '') 
    });

    // Verificar se é solicitação de teste
    if (!detectarSolicitacaoTeste(mensagem)) {
      await salvarLog({
        phoneNumber,
        message: mensagem,
        action: 'message_ignored',
        status: 'success',
        response: 'Mensagem não contém palavra-chave de teste'
      });

      return NextResponse.json({
        success: true,
        action: 'ignored',
        message: 'Mensagem não contém solicitação de teste'
      });
    }

    // Verificar rate limiting
    const podeGerarteste = await verificarRateLimit(phoneNumber);
    if (!podeGerarteste) {
      const mensagemLimite = `⚠️ *Limite atingido!*

Você já solicitou um teste recentemente. 
Aguarde ${IPTV_CONFIG.rate_limit_minutes} minutos para solicitar outro teste.

⏰ *Tempo de espera:* ${IPTV_CONFIG.rate_limit_minutes} minutos
📞 *Suporte:* Entre em contato para mais informações`;

      // Tentar enviar mensagem de rate limit diretamente ao WhatsApp
      let envioDirecto = false;
      try {
        envioDirecto = await enviarMensagemWhatsApp(phoneNumber, mensagemLimite);
      } catch (error) {
        console.warn('[WEBHOOK] Erro ao enviar mensagem direta de rate limit:', error);
      }

      await salvarLog({
        phoneNumber,
        message: mensagem,
        action: 'test_rate_limited',
        status: 'rate_limited',
        response: mensagemLimite
      });

      return NextResponse.json({
        success: true,
        action: 'rate_limited',
        message: mensagemLimite,
        phoneNumber,
        directSent: envioDirecto
      });
    }

    // Gerar teste IPTV
    console.log('[WEBHOOK] Gerando teste IPTV para:', phoneNumber);
    const dadosIPTV = await gerarTesteIPTV();

    if (!dadosIPTV || !dadosIPTV.usuario) {
      throw new Error('API IPTV não retornou dados válidos');
    }

    // Formatar mensagem de resposta
    const mensagemResposta = formatarMensagem(dadosIPTV);

    // Tentar enviar mensagem diretamente ao WhatsApp
    let envioDirecto = false;
    try {
      envioDirecto = await enviarMensagemWhatsApp(phoneNumber, mensagemResposta);
    } catch (error) {
      console.warn('[WEBHOOK] Erro ao enviar mensagem direta:', error);
    }

    // Salvar log de sucesso
    await salvarLog({
      phoneNumber,
      message: mensagem,
      action: 'test_generated',
      status: 'success',
      response: mensagemResposta
    });

    const responseTime = Date.now() - startTime;
    console.log('[WEBHOOK] Teste gerado com sucesso em', responseTime, 'ms para:', phoneNumber, 'Envio direto:', envioDirecto);

    return NextResponse.json({
      success: true,
      action: 'test_generated',
      message: mensagemResposta,
      phoneNumber,
      directSent: envioDirecto,
      credentials: {
        usuario: dadosIPTV.usuario,
        senha: dadosIPTV.senha,
        dns: dadosIPTV.dns,
        validade: dadosIPTV.validade
      },
      responseTime
    });

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
    const responseTime = Date.now() - startTime;

    console.error('[WEBHOOK] Erro:', errorMessage, 'em', responseTime, 'ms');

    await salvarLog({
      phoneNumber,
      message: mensagem,
      action: 'test_error',
      status: 'error',
      error: errorMessage
    });

    return NextResponse.json({
      success: false,
      error: errorMessage,
      phoneNumber,
      responseTime
    }, { status: 500 });
  }
}

// Handler GET para verificação de saúde
export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url);
    const token = url.searchParams.get('hub.verify_token');
    const challenge = url.searchParams.get('hub.challenge');

    // Verificação do webhook (comum no WhatsApp Business API)
    if (token && challenge) {
      const expectedToken = process.env.WHATSAPP_VERIFY_TOKEN || 'your-verify-token';
      
      if (token === expectedToken) {
        console.log('[WEBHOOK] Webhook verificado com sucesso');
        return new NextResponse(challenge);
      } else {
        console.warn('[WEBHOOK] Token de verificação inválido');
        return NextResponse.json({ error: 'Invalid verify token' }, { status: 403 });
      }
    }

    // Status de saúde da API
    return NextResponse.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      version: '1.0.0',
      endpoints: {
        webhook: '/api/webhook/whatsapp',
        health: '/api/webhook/whatsapp (GET)'
      },
      config: {
        rate_limit_minutes: IPTV_CONFIG.rate_limit_minutes,
        triggers: IPTV_CONFIG.triggers.length,
        api_configured: !!IPTV_CONFIG.api_key
      }
    });

  } catch (error) {
    console.error('[WEBHOOK] Erro no GET:', error);
    return NextResponse.json({ 
      status: 'error', 
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}
