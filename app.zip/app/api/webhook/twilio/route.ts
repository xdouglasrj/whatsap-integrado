
import { NextRequest, NextResponse } from "next/server";
import { PrismaClient } from '@prisma/client';
import twilio from 'twilio';

const prisma = new PrismaClient();
const MessagingResponse = twilio.twiml.MessagingResponse;

export const dynamic = "force-dynamic";

// Função para processar solicitação de teste IPTV
async function processIPTVRequest(phoneNumber: string): Promise<string> {
  try {
    // Verificar rate limiting (mesmo código do webhook principal)
    const now = new Date();
    const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000);
    
    const recentRequests = await prisma.webhookLog.count({
      where: {
        phoneNumber,
        createdAt: { gte: fiveMinutesAgo }
      }
    });

    if (recentRequests >= 2) {
      return "🚫 Limite atingido! Você pode solicitar apenas 2 testes a cada 5 minutos. Tente novamente mais tarde.";
    }

    // Buscar configuração IPTV ativa
    const iptvSite = await prisma.iPTVSite.findFirst({
      where: { isActive: true }
    });

    if (!iptvSite) {
      return "❌ Nenhum site IPTV configurado. Entre em contato com o suporte.";
    }

    // Gerar teste (simulado - ajuste conforme sua API)
    const testCredentials = {
      usuario: `teste_${Date.now()}`,
      senha: Math.random().toString(36).substring(2, 10),
      validade: "6 horas"
    };

    // Log da solicitação
    await prisma.webhookLog.create({
      data: {
        phoneNumber,
        message: "Solicitação via Twilio WhatsApp",
        action: "test_generated",
        status: "success",
        response: JSON.stringify(testCredentials),
        metadata: {
          provider: "twilio",
          iptvSiteId: iptvSite.id,
          iptvSiteName: iptvSite.name
        }
      }
    });

    return `🎉 *Teste IPTV Gerado com Sucesso!*

👤 *Usuário:* ${testCredentials.usuario}
🔐 *Senha:* ${testCredentials.senha}
⏰ *Válido por:* ${testCredentials.validade}

📱 *Site:* ${iptvSite.name}

_Aproveite seu teste!_ ✅`;

  } catch (error) {
    console.error('Erro ao processar solicitação IPTV:', error);
    return "❌ Erro interno. Tente novamente ou entre em contato com o suporte.";
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.text();
    const params = new URLSearchParams(body);
    
    const from = params.get('From'); // Número do remetente
    const messageBody = params.get('Body')?.toLowerCase(); // Mensagem recebida
    
    if (!from) {
      return NextResponse.json({ error: 'Número do remetente não encontrado' }, { status: 400 });
    }

    // Limpar número (remover prefixo whatsapp:)
    const phoneNumber = from.replace('whatsapp:', '');
    
    // Verificar se é uma solicitação de teste
    const testKeywords = ['teste', 'trial', 'demo', 'test', 'iptv'];
    const isTestRequest = testKeywords.some(keyword => 
      messageBody?.includes(keyword)
    );

    let responseMessage = '';
    
    if (isTestRequest) {
      responseMessage = await processIPTVRequest(phoneNumber);
    } else {
      responseMessage = `👋 Olá! Seja bem-vindo!

Para solicitar um teste IPTV, envie uma das palavras:
• teste
• trial  
• demo

🔥 *Testes disponíveis 24/7!*`;
    }

    // Criar resposta TwiML
    const twiml = new MessagingResponse();
    twiml.message(responseMessage);

    return new NextResponse(twiml.toString(), {
      headers: {
        'Content-Type': 'text/xml',
      },
    });

  } catch (error) {
    console.error('Erro no webhook Twilio:', error);
    
    const twiml = new MessagingResponse();
    twiml.message("❌ Erro interno. Tente novamente mais tarde.");
    
    return new NextResponse(twiml.toString(), {
      headers: {
        'Content-Type': 'text/xml',
      },
    });
  }
}

// Webhook de verificação do Twilio
export async function GET(request: NextRequest) {
  return NextResponse.json({
    message: "Twilio WhatsApp webhook ativo",
    timestamp: new Date().toISOString()
  });
}
