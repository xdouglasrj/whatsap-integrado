// Este endpoint foi migrado para /api/webhook/whatsapp
// Mantido para compatibilidade com versões anteriores

import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  // Redirecionar para o novo endpoint WhatsApp
  return NextResponse.redirect(new URL('/api/webhook/whatsapp', request.url), 301);
}

export async function GET(request: NextRequest) {
  return NextResponse.json({
    message: "Este endpoint foi migrado para /api/webhook/whatsapp",
    new_endpoint: "/api/webhook/whatsapp", 
    status: "deprecated"
  });
}